<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

use App\Post;
use App\Like;
use App\Block;
use App\Notifications;
use App\Topic;
use DB;


class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'username' , 'email', 'password','first_name', 'last_name', 'location', 'image', 'phone'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function isAdmin()
    {
        return DB::table('ADMINS')
            ->where('user_id', $this->id)
            ->first() ? true : false;
    }
    public function getName()
    {
        if($this->first_name && $this->last_name){
            return $this->first_name." ".$this->last_name;
        }
        return $this->first_name ? : null;
    }
    public function getNameOrUsername()
    {
        return $this->getName() ? :'@'.$this->username;
    }
    public function getFirstNameOrUsername(){
        return $this->first_name ? : '@'.$this->username;
    }
    public function getNameFirstNameOrUsername()
    {
        return $this->getName() ? : ('@'.$this->username);
    }
    public function getDp()
    {
        return $this->image?:'dp.png';
    }
    public function getNumber()
    {
        return '+923'.$this->phone;
    }
    public function friendsOfMine()
    {
        return $this->belongsToMany('App\User', 'friends', 'user_id', 'friend_id');
    }
    public function friendsOf()
    {
        return $this->belongsToMany('App\User', 'friends', 'friend_id', 'user_id');
    }
    public function friends()
    {
        return $this->friendsOfMine()->wherePivot('accepted', true)->get()
            ->merge($this->friendsOf()->wherePivot('accepted', true)->get());
    }
    public function friendRequests()
    {
        return $this->friendsOfMine()->wherePivot('accepted',  false)->get();
    }
    public function friendRequestPending()
    {
        return $this->friendsOf()->wherePivot('accepted',  false)->get();
    }
    public function hasFriendRequestReceived(User $user)
    {
        return (bool) $this->friendRequests()->where('id',$user->id)->count();
    }
    public function hasFriendRequestPending(User $user)
    {
        return (bool) $this->friendRequestPending()->where('id',$user->id)->count();
    }
    public function addFriend(User $user)
    {
        $this->friendsOfMine()->attach($user->id);
    }
    public function deleteFriend(User $user)
    {
        $this->friendsOfMine()->detach($user->id);
        $this->friendsOf()->detach($user->id);
    }
    public function acceptFriendRequest(User $user)
    {
        $this->friendRequests()->where('id',$user->id)->first()->pivot->update([
            'accepted' => true,
        ]);
    }
    public function isFriendWith(User $user)
    {
        return (bool) $this->friends()->where('id', $user->id)->count();
    }

    public function likes()
    {
        return $this->hasMany(Like::class, 'user_id');
    }
    public function hasLikedPost(Post $post)
    {
        return (bool) $post->likes()->where('user_id', $this->id)->count() ;
    }

    public function posts()
    {
        return $this->hasMany(Post::class, "user_id");
    }
    public function getPosts()
    {
        return $this->posts()->get() ;
    }
    public function chats()
    {
        return $this->hasMany(Chat::class, "user_id");
    }
    public function notifications()
    {
        return $this->hasMany(Notifications::class, 'user_id');
    }
    public function hasUnseenNotifications()
    {

        return Notifications::where([
            ['seen', 0],
            ['user_id', $this->id]
            ])->first()?true:false;
    }
    public function hasUnseenFriendRequests()
    {
        return $this->friendsOf()->where('seen', 0)->get()->count()?true:false;
    }
    public function hasUnseenChats()
    {
        return Chat::where([
            ['seen', 0],
            ['receiver_id', $this->id]
            ])->first()?true:false;
    }
    public function hasUnseenTopics()
    {
        // To be defined later
        return false;
    }
    public function groups()
    {
        return $this->hasMany(Group::class);
    }
    public function blocked()
    {
        return $this->belongsToMany(User::class, 'block', 'user_id', 'blocked_id');
    }
    public function hasBlocked($userId)
    {
        $user = User::where('id', $userId)->first();
        return $this->blocked()->get()->contains($user) ? true : false;
    }
    public function isBlockedBy($uid)
    {
        $user = User::where('id', $uid)->first();
        return $user->blocked()->get()->contains($this) ? true : false;
    }
    public function block($user)
    {
        $user = User::where('id', $user)->first();
        if(!$this->blocked()->get()->contains($user)) $this->blocked()->attach($user);
    }
    public function unblock($user)
    {
        $user = User::where('id', $user)->first();
        if($this->blocked()->get()->contains($user)) $this->blocked()->detach($user);

    }
    public function topics()
    {
        return $this->belongsToMany(Topic::class, 'area_users', 'user_id', 'area_id')->wherePivot('area_type', 'App\\Topic')->withTimestamps();
    }
    public function myTopics()
    {
        return $this->topics;
    }
    public function ownedTopics()
    {
        return $this->belongsToMany(Topic::class, 'area_admins', 'admin_id', 'area_id')->wherePivot('area_type', 'App\\Topic')->withTimestamps();
    }
    public function unownedTopics()
    {
        $topics = [];
        foreach ($this->topics as $topic) {
            if ( (!$this->isAdminOfTopic($topic)) && !in_array($topic, $topics) ){
                $topics[count($topics)] = $topic;
            }
        }
        return $topics;
    }
    public function isAdminOfTopic($topic)
    {   
        if ($topic) return $topic->admins->contains($this);
    }
    public function isMemberOfTopic($topic)
    {
        if ($topic) return $topic->users->contains($this);
    }
    public function blockedByArea()
    {
        // return $this->morphedByMany(Topic::class, 'blockable');      To be made later
    }
}
