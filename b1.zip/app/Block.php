<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use App\User;

class Block extends Model
{
    protected $table = 'blockable';

    public function blockable()
    {
    	return $this->morphTo();
    }
    public function user()
    {
    	return $this->belongsTo(User::class, 'user_id');
    }
}
