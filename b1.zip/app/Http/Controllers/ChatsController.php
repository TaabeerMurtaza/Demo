<?php

namespace App\Http\Controllers;

use App\Chat;
use Auth;
use App\User;
use Illuminate\Http\Request;

class ChatsController extends Controller
{
    public function index($user)
    {
        $uid = $user;
        $auth = Auth::user();
        if (Auth::check() && $user == $auth->id) {
            $chats = Chat::where([
                'user_id'=> $uid,
                'receiver_id' => $auth->id ,
            ])->orWhere([
                'receiver_id'=> $uid,
                'user_id' => $auth->id,
            ])->latest()->get();
        }
        ////////////////////////////////////////////////////
        /////////////      UNSUCCESSFUL CODE  /////////////
        //
        // $result = array();
        // foreach ($chats as $element) {
        //     if ($element->user_id == $auth->id) {
        //         $result[$element['receiver_id']][] = $element;
        //      } else {
        //         $result[$element['user_id']][] = $element;
        //     }
        // }
        // $received = $chats->where('user_id', $auth->id);
        // $sent = $chats->where('receiver_id', $auth->id);
        //
        ////////////////////////////////////////////////////

        $final = array();
        $others = array();
        foreach ($chats as $chat ) {
            if(!in_array($chat->other(), $others)){
                $final[count($final)] = $chat;
                $others[count($others)] = $chat->other();
            }
        }
        $chat_1 = $chats = Chat::where([
                'user_id'=> $uid,
                'receiver_id' => $auth->id ,
            ])->orWhere([
                'receiver_id'=> $uid,
                'user_id' => $auth->id,
            ])->oldest()->paginate(30);
        return view('chat.index', ['final' => $final, 'user' => $auth, 'chat_1' => $chat_1]);
    }
    public function chat($userId)
    {
        if(Auth::check() && Auth::user()->id != $userId){
            $chats = Chat::where([
                ['user_id', Auth::user()->id],
                ['receiver_id', $userId],
            ])->orWhere([
                ['user_id', $userId],
                ['receiver_id', Auth::user()->id]
            ])->oldest()->get();
            $other = User::where('id', $userId)->first();
            if(Auth::user()->isFriendWith($other)){
                $unread = Chat::where([
                    ['receiver_id', Auth::user()->id],
                    ['seen', 0]
                ])->get();
                if($unread){
                    foreach ($unread as $chat ) {
                        $chat->update([
                            'seen' => 1
                        ]);
                    }
                }
                return view('chat.chat', ['chats' => $chats, 'other' => $other]);
            }else{
                return redirect()->back()->with('info', 'You can\'t message someone you are not friend with.');
            }
        }
    }
    public function chatAlt($userId)
    {
        return redirect()->route('chat.chat', [$userId, '#end_of_chats']);
    }
    public function post(Request $request, $userId)
    {
        if(Auth::user()){
            $this->validate($request,[
                "msg" => 'max:500',
                'head_image' => 'image'
            ]);
            if($request->file('head_image')){
                $imagePath = request('head_image')->store('uploads','public');
                $msg = auth()->user()->chats()->create([
                    'head_image' => $imagePath,
                    'body' => $request->input("msg"),
                    'receiver_id' => $userId,
                    'seen' => 0
                    ]);
            }else{
                $msg = auth()->user()->chats()->create([
                    'body' => $request->input("msg"),
                    'receiver_id' => $userId,
                    'seen' => 0
                    ]);
            }

                return redirect()->route('chat.chat', [$userId, '#end_of_chats']);
        }
    }
}
