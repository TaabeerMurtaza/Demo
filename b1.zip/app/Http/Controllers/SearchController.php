<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Topic;
use DB;

class SearchController extends Controller
{
    public function getResults(Request $request)
    {
        $query = $request->input('query');
        $users = User::where(DB::raw("first_name || ' ' || last_name"),"LIKE", "%{$query}%")
                        ->orWhere("username", "LIKE", "%{$query}%")
                        ->paginate(50);
        return View('search.results', ['users' => $users]);
    }
    public function getTopicResults(Request $request)
    {
    	$query = $request->input('query');
        $searched_topics = Topic::where("name", "LIKE", "%{$query}%")
                        ->paginate(30);
        return View('topic.search', ['searched_topics' => $searched_topics]);
    }
}
