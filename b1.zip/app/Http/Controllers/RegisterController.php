<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use \App\User;

class RegisterController extends Controller
{
    public function getSignUp()
    {
    	return view('template.register');
    }
    public function postSignUp(Request $request)
    {

    	$this->validate($request,[
            'username' => ['required','unique:users','max:25','alpha_dash'],
            'email' => ['required_without:phone','unique:users','email','max:255'],
            'phone' => ['required_without:email', 'unique:users', 'digits:9'],
            'password' => ['required','min:6', 'same:password_confirmation'],
            'password_confirmation' => ['required']
        ], [
            'numeric' => 'Phone number must be in numbers only (no space or dash)',
            'digits' => 'Phone number must be 9 characters only.'
        ]);

        if(strtolower($request->input('username')) == 'admin') {
            $error = \Illuminate\Validation\ValidationException::withMessages([
               'username' => ['You cannot use username admin'],
            ]);
            throw $error;
        }

        $user = User::create([
            'username' => $request->input('username'),
            'email' => $request->input('email'),
            'phone' => $request->input('phone'),
            'password' => Hash::make($request->input('password')),
        ]);

        // Automatically Post something on sign up
        $post = $user->posts()->create([
                'body' => 'Hi everybody, I\'m new here.',
        ]);

        $admin = User::where('id', 1)->first();
        $reply = $admin->posts()->create([
            'body' => 'Wellcome @'.$user->username.'. I\'m the admin of this site. Contact me for any problem. Wish you best of luck.',
        ]);
        $post->replies()->save($reply);

        $this->postSignIn($request);
        
        return redirect()->route('home')->with('info',"You have successfuly created your account."); // No longer necessary, as User will automatically be logged in and redirected to timeline.
    }
    public function getSignIn()
    {
    	return view('template.login');
    }
    public function postSignIn(Request $request)
    {
    	$this->validate($request,[
            'username' => 'required',
            'password' => 'required',
        ]);
        
        $remember = $request->input('remember');

        if(!Auth::attempt($request->only(['username','password']), $remember)){
            return redirect()->route('login')->with('info',"Cannot sign you in with the details provided.");
        }else{
            return redirect()->route('timeline')->with('info',"You are now logged in.");
        }
    }
    public function SignOut()
    {
        Auth::logout();
        return redirect()->route('login')->with('info','You have successfuly logged out.');
    }
}
