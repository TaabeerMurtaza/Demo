<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Topic;
use App\Post;
use App\User;
use Auth;

class TopicController extends Controller
{
    public function index()
    {
    	$topics = Topic::orderByDesc('updated_at')->get();
        $ownedTopics = Auth::user()->ownedTopics()->get();
        $unownedTopics = Auth::user()->unownedTopics();
        $myTopics = Auth::user()->topics()->orderByDesc('updated_at')->get();
    	return view('topic.index', [
            'topics' => $topics,
            'ownedTopics' => $ownedTopics, 
            'unownedTopics' => $unownedTopics,
            'myTopics' => $myTopics
        ]);
    }
    public function other()
    {
        $topics = Topic::orderByDesc('updated_at')->get();
        $ownedTopics = Auth::user()->ownedTopics()->get();
        $unownedTopics = Auth::user()->unownedTopics();
        $myTopics = Auth::user()->topics()->orderByDesc('updated_at')->get();

        return view('topic.other', [
            'topics' => $topics,
            'ownedTopics' => $ownedTopics, 
            'unownedTopics' => $unownedTopics,
            'myTopics' => $myTopics
        ]);
    }
    public function create(Request $request)
    {
    	$this->validate($request, [
    		'topicName' => 'required|max:25'
    	], [
            'max' => 'Topic name must be less than 25 characters long.'
        ]);

    	$topic = Auth::user()->topics()->create([
    		'name' => $request->input('topicName'),
    		'type' => 'Public',
            'user_id' => Auth()->user()->id
    	]);
    	$topic->users()->attach(Auth::user(), [
    		'user_id' =>  Auth::user()->id,
    		'area_type' => 'App\\Topic',
    		'area_id' => $topic->id
    	]);
    	$topic->admins()->attach(Auth::user(), [
    		'admin_id' =>  Auth::user()->id,
    		'area_type' => 'App\\Topic',
    		'area_id' => $topic->id
    	]);
    	return redirect()->route('topic.index')->with('info', 'Topic created successfully.');
    }
    public function open($topicId)
    {
    	$topic = Topic::where('id', $topicId)->first();
    	if (!$topic) return redirect()->route('timeline')->with('with', 'Topic does not exist.');
    	$posts = $topic->posts()->notReply()->latest()->paginate(40);
    	$users = $topic->users()->get();
		$admins = $topic->admins()->get();
    	return view('topic.posts', ['posts' => $posts, 'topic' => $topic, 'users' => $users, 'admins' => $admins]);
    }
    public function join($id)
    {
    	$me = Auth::user();
        $topic = Topic::where('id', $id)->first();
        if ($me->topics->contains($topic)) return redirect()->back()->with('info', 'You are already a member of this topic') ;
        $me->topics()->attach($topic, [
            'area_type' => 'App\\Topic',
            'area_id' => $id
        ]);
        return redirect()->back()->with('info', 'You joined topic: '.$topic->name);
    }
    public function leave($id)
    {
    	$me = Auth::user();
        $topic = Topic::where('id', $id)->first();
        $me->topics()->detach($topic);
        return redirect()->back()->with('info', 'You left topic: '.$topic->name);
    }
    public function kickOut(User $user, $id)
    {
        $topic = Topic::where('id', $id)->first();
        if(Auth::user()->isAdminOfTopic($topic)){
            $user->topics()->detach($topic);
            return redirect()->back()->with('info', 'User removed successfully.');
        }
        return redirect()->back()->with('info', 'Only an admin can remove a member.');
    }
    public function post(Request $request, $id)
    {
    	#################################################################
    	# Here I will later put restrictions on who can post a status 	#
    	#################################################################

    	//  Validation
    	$this->validate($request,[
            'post' => 'required|max:1500|min:10',
            'head_image' => 'image',
        ]);
        // If there's an image in post
        if ($request->file('head_image')){
            $imagePath = request('head_image')->store('uploads','custom');
            // $image = $request->file('head_image');
            // $extension = $image->getClientOriginalExtension();
            $post = auth()->user()->posts()->create([
                'body' => $request->input('post'),
                'head_image' => $imagePath,
                'area_type' => 'App\\Topic',
                'area_id' => $id
            ]);
        }
        // else (if it is text-only post)
        else{
            $post = auth()->user()->posts()->create([
                'body' => $request->input('post'),
                'area_type' => 'App\\Topic',
                'area_id' => $id
            ]);
        }
        // Updating last post
        $topic = Topic::where('id', $id)->first();
        $topic->update([
            'last_post' => $post->id
        ]);

        return redirect()->back()->with('info', 'Posted successfully.');
    }
    public function reply(Request $request, Post $post, $id)
    {
    	#################################################################
    	# Here I will later put restrictions on who can post a reply 	#
    	#################################################################


        #################################################################
        ###########################   Update: ###########################
        #                                                               #
        #                 Reply not allowed on Topic Posts              #
        #                                                               #
        #################################################################


    	// Validation
    	$this->validate($request,[
            "reply-{$post->id}" => 'required|max:500'
        ],[
            'required' => 'Please fill the reply field...'
        ]);
        $reply = auth()->user()->posts()->create([
            'body' => $request->input("reply-{$post->id}"),
            'area_type' => 'App\\Topic',
            'area_id' => $id
        ]);
        $post->replies()->save($reply);

        // Notifying users of reply
        $me = Auth::user();
        $nctrl = new NotificationsController();
        foreach ($post->getParticipants() as $participant) {

            if($post->user_id == $participant->id){
                $post_owner = 'your';
            }else{
                $post_owner = User::where('id', $post->user_id)->first()->username."'s";
            }
            $link = '/timeline/'.$post->id.'/open';
            $noti_body = $me->username.' replied to '.$post_owner.' post.';
            $nctrl->notify(
                $participant->id,
                'Post',
                $post->id,
                $post->user_id,
                $noti_body,
                1,
                $link
            );
        }

        // Redirecting back
        return redirect()->back()->with('info', 'Repllied on post.');
    }
}
