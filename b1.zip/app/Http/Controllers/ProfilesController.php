<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

use App\User;
use App\Post;
use Auth;


class ProfilesController extends Controller
{
    public function index(User $user)
    {
		$statuses = Post::NotReply()->where('user_id', $user->id)->latest()->paginate(10);

        return view('profile.index', ['user' => $user, 'statuses' => $statuses]);
    }
    public function edit()
    {
    	$this->middleware('auth');

		return view('profile.edit',['user' => Auth()->User()]);
    }
    public function update(Request $request)
    {
    	$this->middleware('auth');
    	$this->validate($request,[
    		'first_name' => "required|alpha|max:20",
    		'last_name' => 'required|alpha|max:20',
    		'location' => 'max:50',
    		'email' => 'email',
    		'image' => 'image|nullable'
        ], [
            'required' => 'You must fill this field...'
        ]);
        $oldImage = Auth::user()->image ? : null;
        if(request('image')){
            $imagePath = request('image')->store('uploads','custom');
            $image = $request->file('image');
            Auth::user()->update([
                'first_name' => $request->input('first_name'),
                'last_name' => $request->input('last_name'),
                'location' => $request->input('location'),
                'email' => $request->input('email'),
                'image' => $imagePath,
            ]);
        }else{
            Auth::user()->update([
                'first_name' => $request->input('first_name'),
                'last_name' => $request->input('last_name'),
                'location' => $request->input('location'),
                'email' => $request->input('email'),
            ]);
        }

        // Deleting the old image If Exists
        if ($oldImage) File::delete('storage/'.$oldImage);

    	return redirect()->route('home');
		}
}
