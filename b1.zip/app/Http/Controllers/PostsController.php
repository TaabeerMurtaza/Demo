<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use App\Http\Controllers\NotificationsController;
use Auth;
use App\Post;
use App\User;
use Illuminate\Support\Facades\Notification;
use Agent;

class PostsController extends Controller
{
    public function __Construct()
    {
        // $this->middleware('auth');
    }
    public function index()
    {
        // if(Auth::check()){
            // $statuses = Post::NotReply()->where(function($query){
            //     return $query->where('user_id', Auth::user()->id)->
            //     orWhereIn('user_id', Auth::user()->friends()->pluck('id'));
            // })->latest()->paginate(10);
        // }
        if (Auth::user()) $myTopics = Auth::user()->topics()->orderByDesc('updated_at')->get();
        else $myTopics = null;
        $statuses = Post::notReply()->notUnderTopic()->latest()->paginate(10);
        $d = new Agent();
        $isMobile = $d::isMobile();
        return view('posts.index', ['statuses' => $statuses, 'isMobile' => $isMobile, 'myTopics' => $myTopics]);
    }
    public function postStatus(Request $request)
    {
        $this->validate($request,[
            'status' => 'required|max:1000|min:60',
            'head_image' => 'image',

        ]);

        // Mention feature
        // $ex = explode( ' ', $request->input('status'));
        // foreach ($ex as $w) {
        //     if (substr_count($w, '@')){
        //         $user = User::where('username', str_replace("@", '', $w))->first();
        //         echo $user ? $user->getFirstNameOrUsername():'';
        //     }
        // }
        

        if ($request->file('head_image')){
            $imagePath = request('head_image')->store('uploads','custom');
            // $image = $request->file('head_image');
            // $extension = $image->getClientOriginalExtension();
            auth()->user()->posts()->create([
                'body' => $request->input('status'),
                'head_image' => $imagePath,
            ]);
        }else{
            auth()->user()->posts()->create([
                'body' => $request->input('status'),
            ]);
        }


        return redirect()->route('timeline')->with('info',"Status posted successfully...");
    }
    public function postReply(Request $request, $statusId)
    {
        $this->validate($request,[
            "reply-{$statusId}" => 'required|max:500'
        ],[
            'required' => 'Please fill the reply field...'
        ]);
        $status = Post::notReply()->find($statusId);
        $logged_in_user = Auth::user();
        $status_owner = User::find($status->user_id);

        if(!$status){
            return redirect()->route('home');
        }

        if(!$logged_in_user){
            return redirect()->route('home')->with('info',"You need to sign in first...");
        }
        // For now, anyone can reply on a post except for blocked users
        // if(($logged_in_user->id != $status->user_id) && !($logged_in_user->isFriendWith($status->user))){
        //     return redirect()->route('home')->with('info',"Naa......");
        // }
        if($logged_in_user->isBlockedBy($status_owner->id)){
            return redirect()->back()->with('info',"You are blocked by other user.");
        }
        if($logged_in_user->hasBlocked($status_owner)){
            return redirect()->back()->with('info',"You can not post because you have blocked the other user.");
        }
        $reply = auth()->user()->posts()->create([
            'body' => $request->input("reply-{$statusId}"),
        ]);
        $status->replies()->save($reply);

        // Notifying users of reply
        $nctrl = new NotificationsController();
        foreach ($status->getParticipants() as $participant) {
            if($reply->user_id != $participant->id){
                if($status->user_id == $participant->id){
                    $post_owner = 'your';
                }else{
                    $post_owner = User::where('id', $status->user_id)->first()->username."'s";
                }
                $link = '/timeline/'.$statusId.'/open';
                $noti_body = $logged_in_user->username.' replied to '.$post_owner.' post.';

                $nctrl->notify(
                    $participant->id,
                    'Post',
                    $statusId,
                    $status->user_id,
                    $noti_body,
                    1,
                    $link
                );
            }
        }

        return redirect()->back();
    }
    public function postDelete($statusId)
    {
        $post = Post::where('id', $statusId)->first();

        // Ensure the post exists
        if (!$post) return redirect()->back()->with('info', 'Post does not exist.');

        $replies = $post->replies()->get();
        $info = '';

        // Only a post owner or admin can delete a post.
        if(Auth::user()->id != $post->user_id && !Auth::user()->isAdmin()) return redirect()->back()->with('info', 'You can only delete your own post');

        // Deleting the head image
        File::delete('storage/'.$post->head_image);

        // Deleting all the replies FIRST
        if($replies){
            foreach ($replies as $reply) {
                if ($reply)    // Just as safe measure to ensure the reply exists
                {
                    $reply->delete();
                    $info = 'All replies deleted Successfully. ';
                }
            }

        }

        // Now deleting the original/main post/reply 
        $post->delete();
        if($post->parent_id) $info .= 'Reply deleted Succussfully...';
        else $info .= 'Post deleted Succussfully...';

        return redirect()->back()->with('info', $info);

    }
    public function getLike($statusId)
    {
        $status = Post::find($statusId);
        if(!$status){
            return redirect()->route('home');
        }
        if(Auth::user()->hasLikedPost($status)){
            return redirect()->back()->with('info', 'You can\'t like twice');
        }
        Auth::user()->likes()->save($status->likes()->create([
            
        ]));
        return redirect()->back();
    }
    public function getOpen($statusId)
    {
        $status = Post::where('id', $statusId)->first();
        if(!$status) return redirect()->route('timeline');
        $user = User::where('id', $status->user_id)->first();
        $participants = $status->getAllParticipants();
        // foreach ($status->replies as $key => $reply) {
        //     $usr = User::where('id', $reply->user_id)->first();
        //     if(!in_array($usr, $participants)){
        //         $participants[count($participants)] = $usr;
        //     }
        // }
        $replies = $status->replies()->get() ? $status->replies()->latest()->paginate(30) : [];

        return view('posts.solo', ['status' => $status, 'user' => $user, 'partis' => $participants, 'replies' => $replies]);
    }
}
