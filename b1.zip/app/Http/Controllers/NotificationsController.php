<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Notifications;
use App\Post;
use App\User;

class NotificationsController extends Controller
{
    public function index($userId)
    {
        if (Auth::user()->id == $userId){
            $notifications = Notifications::where('user_id', $userId)->latest()->paginate(20);

            return view('notification.index', ['notes' => $notifications]);
        }else{
            return redirect()->back();
        }
    }
    public function notify($userId, $type, $parent_obj_id, $cause_usr_id, $body, $status, $link)
    {
        $user = User::where('id', $userId)->first();
        $noti = $user->notifications()->create([
            'user_id' => $userId,
            'type' => $type,
            'parent_object_id' => $parent_obj_id,
            'cause_user_id' => $cause_usr_id,
            'seen' => 0,
            'body' => $body,
            'link' => $link,
            'status' => $status
        ]);
        return redirect()->back();
    }
    public function open($notId)
    {
        $noti = Notifications::where('id', $notId)->first();
        $noti->update([
            'seen' => 1
        ]);
        return redirect($noti->link);
    }
    public function read()
    {
        $unread = Notifications::where([
            'user_id' => Auth::user()->id,
            'seen' => 0
        ])->get();
        if($unread){
           foreach ($unread as $noti) {
                $noti->update(['seen' => 1]);
            }
            return redirect()->back()->with('info', 'All notifications marked read...');
        }else{
            return redirect()->back()->with('info', 'No more notifications');
        }
    }
}
