<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\User;

class BlockController extends Controller
{
    public function block($user)
    {
    	$auth = Auth::user();
    	$other = User::find($user);
    	if(Auth::user()->isFriendWith($other)){
    		Auth()::user()->deleteFriend($user);
    	}
    	Auth::user()->block($user);
    	return redirect()->back()->with('info', 'User blocked successfully...');
    }
    public function unblock($user)
    {
    	Auth::user()->unblock($user);
    	return redirect()->back()->with('info', 'User Unblocked successfully...');
    }
    public function blocked()
    {

    	dd(Auth::user()->blocked);
    }
}
