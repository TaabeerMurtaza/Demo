<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use App\User;

class FriendsController extends Controller
{
    public function __Construct()
    {
        /* Gets Called on every instance creation */
    }
    public function index()
    {
        $friends = Auth::user()->friends();
        $requests = Auth::user()->friendRequestPending();
        $unseen = Auth::user()->friendsOf()->wherePivot('seen', 0)->get();
        if($unseen){
            foreach ($unseen as $val ) {
                $val->pivot->update([
                    'seen' => 1
                ]);
            }
        }
        return view('profile.friends',['friends' => $friends, 'requests' => $requests]);
    }

    public function getAdd(User $user)
    {
        if( Auth()->user()->isBlockedBy($user->id) || Auth()->user()->hasBlocked($user->id) ){  
            return redirect()->back()->with('info', 'You can\'t send a friend request to this user. ');
        }
        if(Auth()->user()->hasFriendRequestReceived($user) ||
        Auth()->user()->hasFriendRequestPending($user)){
            return redirect()->route('home')->
            with('info',"Friend request already pending...");
        }
        if(Auth()->user()->isFriendWith($user)){
            return redirect()->route('home')->
            with('info',"You are already friends.");
        }
        Auth()->user()->addFriend($user);
        return redirect()->route('profile.index', $user->id)->
                with('info','Friend Request sent...');
    }
    public function getAccept(User $user)
    {
        if(Auth()->user()->hasFriendRequestReceived($user) ){
            return redirect()->route('home')->
            with('info',"You already sent your friend request..");
        }
        if(Auth()->user()->isFriendWith($user)){
            return redirect()->route('home')->
            with('info',"You are already friends.");
        }
        $user->acceptFriendRequest(Auth()->user());

        return redirect()->back()->
                with('info','Friend Request accepted...');
    }
    public function getDelete(User $user)
    {
        if(!Auth()->user()->isFriendWith($user)){
            return redirect()->route('home')->
            with('info',"You are already not friends.");
        }
        Auth()->user()->deleteFriend($user);
        return redirect()->back()->
                with('info','Friend Removed...');
    }

}
