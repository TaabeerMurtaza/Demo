<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use Agent;
class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        $d = new Agent();
        $isMobile = $d::isPhone();
        $isTablet = $d::isTablet();
        $isDesktop = $d::isDesktop();
        return View::share(
            [
                'isMobile' => $isMobile,
                'isTablet' => $isTablet,
                'isDesktop' => $isDesktop
            ]
        );
    }
}
