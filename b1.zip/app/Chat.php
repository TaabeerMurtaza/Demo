<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Faker\Provider\DateTime;

use App\User;

class Chat extends Model
{
    protected $table = 'chats';
    protected $fillable = [

        'user_id',
        'receiver_id',
        'head_image',
        'body',
        'seen',

    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
    public function other()
    {
        if ($this->user_id == Auth::user()->id){
            return User::find($this->receiver_id);
        }else{
            return User::find($this->user_id);
        }
    }
    public function getDate()
    {
        $date = $this->created_at;
        if(DateTime::dateTimeThisYear()->format('Y')+1 == $date->format('Y')){
            return $date->format('F d');
        }
        return $date->format('d-F-Y');
    }
    public function getTime()
    {
        return $this->created_at->format('H:i a | F d');
    }

}
