<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Faker\Provider\DateTime;

use App\User;
use App\Post;

class Topic extends Model
{
    protected $table = 'topics';
    protected $fillable = [
    	'name',
        'type',
        'last_post'
    ];

    public function admins()
    {
    	return $this->belongsToMany(User::class, 'area_admins', 'area_id', 'admin_id')->wherePivot('area_type', 'App\\Topic')->withTimestamps();
    }
    public function users()
    {
    	return $this->belongsToMany(User::class, 'area_users', 'area_id', 'user_id')->wherePivot('area_type', 'App\\Topic')->withTimestamps();
    }
    public function posts()
    {
    	return $this->hasMany(Post::class, 'area_id');
    }
    public function latestPost()
    {
        return $this->posts()->notReply()->latest()->first();
    }
    public function latestReply()
    {
        return $this->posts()->isReply()->latest()->first();
    }
    public function latestFromMyTopics()
    {
        $topics = Auth::user()->topics;
        dd($topics);
        return $this;
    }
    public function getLastPost()
    {
        return Post::where('id', $this->last_post)->first();
    }
    public function blocked()
    {
        // return $this->morphToMany(User::class , 'blockable');        To be made later
    }
    public function updateDateTime()
    {
        // For later
    }

}
