<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;
use App\Like;
use App\Topic;

class Post extends Model
{
    protected $table = 'posts';
    protected $fillable = [
        'body',
        'head_image',
        'area_type',
        'area_id'
    ];
    public function user()
    {
        return $this->belongsTo(User::class,'user_id');
    }
    public function scopeNotReply($query)
    {
        return $query->where('parent_id', null);
    }
    public function scopeIsReply($query)
    {
        return $query->where('parent_id', !null);
    }
    public function replies()
    {
        return $this->hasMany(Post::class, 'parent_id', 'id');
    }
    public function likes()
    {
        return $this->morphMany(Like::class, 'likeable');
    }
    public function getLastThree()
    {
        $st = $this->latest()->get();
        $ar = [];
        foreach ($st as $key => $value) {
            if($key < 3)$ar[$key] = $value;
            else break;
        }
        return $ar;
    }
    public function getAllParticipants()
    {
        if($this->parent_id == null){
            $status = $this;
            $participants = [];
            foreach ($status->replies as $key => $reply) {
                $usr = User::where('id', $reply->user_id)->first();
                if(!in_array($usr, $participants)){
                    $participants[count($participants)] = $usr;
                }
            }
            return $participants;
        }else{
            return null;
        }
    }
    public function getParticipants()
    {
        if($this->parent_id == null){
            $status = $this;
            $status_owner = User::where('id', $status->user_id)->first();
            $participants = [$status_owner];
            foreach ($status->replies as $key => $reply) {
                $usr = User::where('id', $reply->user_id)->first();
                if( (!in_array($usr, $participants)) && ($usr != auth()->user())){
                    $participants[count($participants)] = $usr;
                }
            }
            return $participants;
        }else{
            return null;
        }
    }
    public function topic()
    {
        return $this->belongsTo(Topic::class, 'area_id', 'id')->wherePivot('area_type', 'App\\Topic');
    }
    public function scopeUnderTopic($query)
    {
        return $query->where([
            'area_id' => !null,
            'area_type' => 'App\\Topic'
        ]);
    }
    public function scopeNotUnderTopic($query)
    {
        return $query->where('area_type' , '!=', 'App\\Topic')->OrWhere('area_type', null);
    }
    public function owner()
    {
        return User::where('id', $this->user_id)->first();
    }
}
