<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;

class Notifications extends Model
{
    protected $table = 'notifications';
    protected $fillable = [
        'user_id',
        'type',
        'parent_object_id',
        'cause_user_id',
        'seen',
        'body',
        'status',
        'link'

    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
