<nav class="navbar navbar-expand-xl sticky-top navbar-dark text-light bg-dark mb-3 border-bottom row">
    <a class="navbar-brand m-0 col-2" href="<?php echo e(route('home')); ?>">
        <span class="text-yellow <?php echo e(($isMobile) ? 'relative-font font-weight-bold' : ''); ?>">
            H<span class="text-light">a</span><span class="text-yellow">s</span><span class="text-light">o</span><span class="text-yellow">l</span><span class="text-light">a</span>
        </span>
    </a>
    
    <ul class="nav nav-pills nav-fill w-auto col-8 row py-2">
        <?php if(Auth::check()): ?>
        <li class="nav-item col-3">
            <a class="px-auto nav-link " href="<?php echo e(route('timeline')); ?>">
                <span class="text-light">
                    
                    <svg fill="#ffffff" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" width="70px" height="70px">
                        <path d="M 24.962891 1.0546875 A 1.0001 1.0001 0 0 0 24.384766 1.2636719 L 1.3847656 19.210938 A 1.0005659 1.0005659 0 0 0 2.6152344 20.789062 L 4 19.708984 L 4 46 A 1.0001 1.0001 0 0 0 5 47 L 18.832031 47 A 1.0001 1.0001 0 0 0 19.158203 47 L 30.832031 47 A 1.0001 1.0001 0 0 0 31.158203 47 L 45 47 A 1.0001 1.0001 0 0 0 46 46 L 46 19.708984 L 47.384766 20.789062 A 1.0005657 1.0005657 0 1 0 48.615234 19.210938 L 41 13.269531 L 41 6 L 35 6 L 35 8.5859375 L 25.615234 1.2636719 A 1.0001 1.0001 0 0 0 24.962891 1.0546875 z M 25 3.3222656 L 44 18.148438 L 44 45 L 32 45 L 32 26 L 18 26 L 18 45 L 6 45 L 6 18.148438 L 25 3.3222656 z M 37 8 L 39 8 L 39 11.708984 L 37 10.146484 L 37 8 z M 20 28 L 30 28 L 30 45 L 20 45 L 20 28 z"/>
                    </svg>
                    

                </span>
            </a>
        </li>
        <li class="nav-item col-3">
            <a class="px-auto nav-link " href="<?php echo e(route('chat.index', Auth::user()->id)); ?>">
                <span class="text-light">
                    
                    <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="90px" height="90px" viewBox="0 0 110 110" enable-background="new 0 0 110 110" xml:space="preserve">
                        <g>
                            <path fill="#FFFFFF" d="M108.079,54.517c0-24.421-18.476-44.52-42.209-47.101c16.38,7.462,27.774,23.963,27.774,43.136 c0,26.172-21.218,47.386-47.391,47.386c-1.762,0-3.499-0.113-5.21-0.299c5.988,2.732,12.636,4.267,19.648,4.267 c8.028,0,15.589-2,22.216-5.521l19.235,6.801l-3.717-20.004C104.479,75.223,108.079,65.289,108.079,54.517z"/>
                            <path fill="#<?php echo e($US_chats ? 'ffdb00' : 'ffffff'); ?>" d="M45.892,6.813c-24.246,0-43.971,19.724-43.971,43.969c0,9.699,3.097,18.893,8.957,26.593l0.916,1.212 l-2.91,15.665l15.07-5.328l1.327,0.702c6.3,3.352,13.428,5.122,20.611,5.122c24.242,0,43.967-19.723,43.967-43.966 S70.134,6.813,45.892,6.813z"/>
                        </g>
                    </svg>
                    

                </span>
            </a>
        </li>
        <li class="nav-item col-3">
            <a class="px-auto nav-link " href="<?php echo e(route('notification.index', Auth::user()->id)); ?>">

                <span class=" text-light ">
                    
                    <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="120px" height="120px" viewBox="0 0 110 110" enable-background="new 0 0 110 110" xml:space="preserve">
                        <g>
                            <path fill="#<?php echo e($US_noti ? 'ffdb00' : 'ffffff'); ?>" d="M75.629,55L49.468,36.347l-3.681,32.932c-0.27,2.414,1.833,4.373,4.697,4.373h46.117 c2.865,0,5.404-1.955,5.676-4.373l3.682-32.932L75.629,55z"/>
                            <polygon fill="#FFFFFF" points="98.783,36.521 57.152,36.521 76.433,50.268   "/>
                            <rect x="19.25" y="66.793" fill="#FFFFFF" width="19.554" height="6.859"/>
                            <rect x="12.732" y="51.569" fill="#FFFFFF" width="26.072" height="6.863"/>
                            <rect x="4.042" y="36.347" fill="#FFFFFF" width="34.763" height="6.861"/>
                        </g>
                    </svg>
                    

                </span>
            </a>
        </li>
        <li class="nav-item col-3">
            <a class="px-auto nav-link  " href="<?php echo e(route('friends.index')); ?>">
                <span class="text-light">
                    
                    <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="110px" height="110px" viewBox="0 0 110 110" enable-background="new 0 0 110 110" xml:space="preserve">
                        <g>
                            <path fill="#ffffff" d="M43.623,59.297c-1.243-0.952-2.378-2.082-3.396-3.349c-0.819-0.384-1.649-0.766-2.514-1.135 c-1.53-0.656-2.177-1.952-2.559-3.346c0.649-0.217,1.275-0.502,1.886-0.823c-1.431-3.279-2.236-7.009-2.236-10.938 c0-7.92,3.257-14.919,8.206-19.079c-2.742-4.348-6.919-7.13-11.603-7.13c-8.262,0-14.958,8.642-14.958,19.302 c0,9.093,4.879,16.697,11.438,18.742c-0.426,1.37-1.141,2.673-2.972,3.457C9.042,61.796,2.238,71.767,2.238,89.595h18.725 C22.577,75.154,29.626,65.813,43.623,59.297z"/>
                            <path fill="#ffffff" d="M82.993,54.813c-1.53-0.656-2.175-1.952-2.559-3.346c6.443-2.15,11.21-9.68,11.21-18.667 c0-10.66-6.695-19.302-14.956-19.302c-4.896,0-9.229,3.048-11.957,7.741c4.568,4.213,7.544,10.912,7.544,18.469 c0,3.731-0.737,7.295-2.05,10.466c0.932,0.578,1.916,1.049,2.943,1.37c-0.426,1.37-1.141,2.673-2.973,3.457 c-1.541,0.66-2.971,1.36-4.341,2.084c-0.726,0.782-1.497,1.504-2.319,2.144c15.045,6.969,22.648,16.346,24.432,30.37h19.794 C107.763,71.321,99.366,61.821,82.993,54.813z"/>
                            <path fill="#<?php echo e($US_freqs ? 'ffdb00' : 'ffffff'); ?>" d="M59.846,61.718c-1.532-0.656-2.178-1.952-2.557-3.345c6.441-2.149,11.208-9.681,11.208-18.666 c0-10.661-6.697-19.303-14.957-19.303c-8.263,0-14.959,8.641-14.959,19.303c0,9.092,4.878,16.697,11.438,18.742 c-0.428,1.369-1.141,2.67-2.972,3.455c-15.877,6.798-22.68,16.768-22.68,34.599h60.247C84.615,78.227,76.218,68.726,59.846,61.718z "/>
                        </g>
                    </svg>

                    
                </span>
            </a>
        </li>
        <?php else: ?>
        <ul class="nav nav-pills ml-auto font-weight-bold <?php echo e($isMobile ? 'relative-font' : ''); ?>">
            <li class="nav-item ">
                <a class="nav-link text-light" href="<?php echo e(route('login')); ?>">
                    Sign in
                </a>
            </li>
            <li class="nav-item ">
                <a class="nav-link text-light" href="<?php echo e(route('register')); ?>">
                    Register
                </a>
            </li>
        </ul>
        <?php endif; ?>
    </ul>
    <?php if(Auth::check()): ?>
        <button aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="scale navbar-toggler col-2 <?php if($US_noti | $US_chats | $US_freqs): ?> border-light custom-nav-toggler <?php endif; ?>" data-target="#navbarSupportedContent" data-toggle="collapse" type="button">
            <span class="text-light">
                
                <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="170px" height="170px" viewBox="0 0 110 110" enable-background="new 0 0 110 110" xml:space="preserve">
                    <g>
                        <path fill="<?php echo e($US_topics ? '#ffdb00' : '#FFFFFF'); ?>" d="M99.202,34.203H29.063c-2.802,0-5.073-2.797-5.073-6.248c0-3.45,2.271-6.248,5.073-6.248h70.139 c2.805,0,5.076,2.797,5.076,6.248C104.278,31.405,102.007,34.203,99.202,34.203z"/>
                        <path fill="<?php echo e($US_topics ? '#ffdb00' : '#FFFFFF'); ?>" d="M11.97,34.203c-1.642,0-3.254-0.667-4.417-1.831c-1.161-1.164-1.83-2.773-1.83-4.419 c0-1.645,0.67-3.253,1.83-4.417c1.164-1.163,2.772-1.83,4.417-1.83c1.646,0,3.258,0.667,4.418,1.83 c1.165,1.164,1.831,2.772,1.831,4.417c0,1.646-0.667,3.255-1.831,4.419C15.23,33.538,13.616,34.203,11.97,34.203z"/>
                        <path fill="<?php echo e($US_topics ? '#ffdb00' : '#FFFFFF'); ?>" d="M99.202,60.859H29.063c-2.802,0-5.073-2.794-5.073-6.245c0-3.452,2.271-6.248,5.073-6.248h70.139 c2.805,0,5.076,2.797,5.076,6.248C104.278,58.065,102.007,60.859,99.202,60.859z"/>
                        <path fill="<?php echo e($US_topics ? '#ffdb00' : '#FFFFFF'); ?>" d="M11.97,60.859c-1.642,0-3.254-0.664-4.414-1.828c-1.164-1.161-1.834-2.771-1.834-4.418 s0.67-3.254,1.834-4.416c1.161-1.164,2.771-1.833,4.414-1.833c1.646,0,3.258,0.671,4.418,1.833 c1.165,1.162,1.831,2.774,1.831,4.416c0,1.646-0.667,3.254-1.831,4.418C15.227,60.195,13.616,60.859,11.97,60.859z"/>
                        <path fill="<?php echo e($US_topics ? '#ffdb00' : '#FFFFFF'); ?>" d="M99.202,88.295H29.063c-2.802,0-5.073-2.798-5.073-6.247c0-3.452,2.271-6.246,5.073-6.246h70.139 c2.805,0,5.076,2.797,5.076,6.246S102.007,88.295,99.202,88.295z"/>
                        <path fill="<?php echo e($US_topics ? '#ffdb00' : '#FFFFFF'); ?>" d="M11.97,88.295c-1.642,0-3.254-0.664-4.414-1.831c-1.164-1.161-1.834-2.771-1.834-4.416 c0-1.646,0.67-3.254,1.834-4.418c1.161-1.164,2.773-1.828,4.414-1.828c1.646,0,3.255,0.664,4.418,1.828 c1.165,1.164,1.834,2.771,1.834,4.418c0,1.645-0.67,3.255-1.834,4.416C15.227,87.631,13.616,88.295,11.97,88.295z"/>
                    </g>
                </svg>
                

                <?php if($US_noti | $US_chats | $US_freqs): ?> <span class="custom-star">*</span> <?php endif; ?>
            </span>
        </button>
    <?php endif; ?>
    <div class="collapse navbar-collapse relative-font" id="navbarSupportedContent">
        
        
        
        <ul class="navbar-nav ml-auto">
            <?php if(Auth::check()): ?>
                <li class="nav-item">
                    <a class="nav-link text-light" href="<?php echo e(route('topic.index')); ?>">
                        <span class="">
                            Topics
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-warning" href="<?php echo e(route('profile')); ?>">
                        <?php echo e(Auth::user()->getFirstNameOrUsername()); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-light" href="<?php echo e(route('profile.edit')); ?>">
                        Update Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-light" href="<?php echo e(route('logout')); ?>">
                        Sign Out
                    </a>
                </li>
            
            <?php endif; ?>
        </ul>
        
        <?php if(Auth::check()): ?>
            <form class="form-inline my-2 my-lg-0 mr-auto" role="search" action="<?php echo e(route('search.results')); ?>">
                <div class="input-group w-100">
                    <input aria-label="Search" class="form-control py-5 <?php echo e($isMobile ? 'relative-font' : ''); ?>" placeholder="Search users" type="search" name="query">
                    <div class="input-group-append">
                        <button class="btn btn-light border border-dark <?php echo e($isMobile ? 'relative-font w-100' : ''); ?>" type="submit">
                            Search
                        </button>
                    </div>
                </div>
            </form>
        <?php endif; ?>
        
    </div>
</nav>
<?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/template/partials/navbar_m.blade.php ENDPATH**/ ?>