<div class="media mx-1 my-3 shadow-cus bg-light p-2">

    <img src="/storage/dp.png" class=" rounded mr-2" alt="Profile Picture of <?php echo e($user->getNameOrUsername()); ?>" style="max-width:70px;">
    <div class="media-body">
        <a href="<?php echo e(route('profile.index', [$user->id])); ?>"><h5 class="mt-0 mb-1 userblock_name"><?php echo e($user->getNameOrUsername()); ?></h5></a>
        <p class="h6 user-location w-100"><?php echo e($user->location); ?></p>
        <?php if(Auth::user()->isAdminOfTopic($topic) && $user->id != Auth::user()->id): ?>
            <a href="<?php echo e(route('topic.kick', ['user' => $user->id, 'id' => $topic->id])); ?>" class="chat-button btn btn-danger btn-sm">kickout</a>
        <?php endif; ?>
    </div>

</div>
<?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/users/partials/block_topic.blade.php ENDPATH**/ ?>