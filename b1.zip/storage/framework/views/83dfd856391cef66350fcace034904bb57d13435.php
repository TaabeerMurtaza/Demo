<?php $__env->startSection('content'); ?>

	<!-- Custom Styles -->
    <link href="<?php echo e(asset('css/custom-styles.css')); ?>" rel="stylesheet"/>
    <!-- End of Custom Styles -->

<div class=" <?php echo e($isMobile ? 'container-fluid' : 'container'); ?> profiles-container">

	<!-- row -->
	<div class="row mt-5 d-md-flex">
		<!-- col1 -->
		<div class="<?php echo e($isMobile ? 'col-12' : 'col-md-8'); ?> order-2 order-md-1">

			<?php if($isMobile): ?>
						
				<div class="img p-2 ">
					<img src="/storage/<?php echo e($user->getDp()); ?>" class="w-100 rounded-circle mb-2" alt="<?php echo e($user->username); ?>">
				</div>
				<div class="intro-wrapper bg-light rounded px-3 pb-5">
					<h1 class="relative-font-2"><?php echo e($user->getNameOrUsername()); ?> <span class="float-right h1"> <?php echo e($user->location); ?> </span></h1>
					<h1 class="relative-font w-100">
						<?php echo e($user->getName() ? ('@'.$user->username) : ''); ?>

						<?php if($user->isFriendWith(Auth::user())): ?>
			                <a href="<?php echo e('/chat/'.$user->id.'#end_of_chats'); ?>" class="chat-button btn btn-primary btn-lg ml-auto relative-font float-right">Send Message</a>
			            <?php elseif($user->hasFriendRequestpending(Auth::user())): ?>
							<span>Friend request sent</span>
			            <?php elseif( $user != Auth::user() && (!$user->isFriendWith(Auth::user())) ): ?>
			                <a href="/friends/add/<?php echo e($user->id); ?>" class="add-friend btn btn-primary relative-font float-right">Add Friend</a>
			            <?php endif; ?>
			            <?php if(Auth()->user()->hasBlocked($user->id)): ?>
							<div class="wrapper w-100 d-block">
								<a href="/unblock/<?php echo e($user->id); ?>" class="btn btn-success <?php echo e($isMobile ? 'relative-font' : ''); ?> float-right">UnBlock</a>
							</div>
						<?php else: ?>
							<?php if(Auth::user() == $user): ?>
								<a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-sm btn-success relative-font_5 float-right">Edit Profile</a>
							<?php else: ?>
								<a href="/block/<?php echo e($user->id); ?>" class="btn btn-danger relative-font float-right">Block</a>
							<?php endif; ?>
						<?php endif; ?>
						<div class="clear-fix"></div>
					</h1>
				</div>

			<?php else: ?>
						
			<div class="media d-none d-md-flex bg-light p-2 rounded shadow-cus">
				<a href="/storage/<?php echo e($user->getDp()); ?>" target="_blank">
					<img src="/storage/<?php echo e($user->getDp()); ?>" class=" rounded-circle mr-2 " alt="Profile Picture of <?php echo e($user->getNameOrUsername()); ?>" style="max-width: <?php echo e($isMobile ? '100%' : '70px'); ?> ;">
				</a>

				<div class="media-body row">
                    <div class="left-part col-8">
                        <h1 class="mt-0 mb-1 h3 userblock_name "><?php echo e($user->getNameFirstNameOrUsername()); ?></h1>
                        <p class="h6 "><?php if($user->getName()): ?> <?php echo e('@'.$user->username); ?> <?php endif; ?></p>
                    </div>
                    <div class="right-part col-4">
                        <?php if(Auth()->user()): ?>
					<?php if(Auth()->user()->hasFriendRequestReceived($user)): ?>
						<div class="wrapper w-100 d-block">
							<p class="float-right">Friend Request Sent</p>
							<div class="clear-fix "></div>
						</div>
					<?php elseif(Auth()->user()->hasFriendRequestPending($user)): ?>
						<div class="wrapper w-100 d-block">
							<a href="/friends/accept/<?php echo e($user->id); ?>" class="btn btn-primary float-right">Accept friend request</a>
							<div class="clear-fix "></div>
						</div>
					<?php elseif(Auth()->user()->isFriendWith($user)): ?>
						<div class="wrapper w-100 d-block">
							<a class="btn btn-danger float-right" href="<?php echo e(route('friends.delete',['user'=> $user])); ?>">Delete Friend</a>
							<div class="clear-fix "></div>
						</div>
					<?php elseif(!(Auth()->user() == $user)): ?>
						<div class="wrapper w-100 d-block">
							<a href="/friends/add/<?php echo e($user->id); ?>" class="btn btn-primary float-right">Add friend</a>
						</div>
					<?php elseif(Auth()->user() == $user): ?>
						<div class="wrapper w-100 d-block">
							<a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-primary float-right">Edit Profile</a>
						</div>
					<?php endif; ?>
				<?php endif; ?>
                        <p class="h6 user-location-right ml-auto float-right mt-2"><?php echo e($user->location); ?></p>
                    </div>
				</div>
			</div>
			<?php endif; ?>
			<hr class="border-dark">

			
			<div class="posts mt-md-5 <?php echo e($isMobile ? 'relative-font' : ''); ?>">

				<?php if(!($statuses->count())): ?>
	                <p>There's no post to show on your timeline...</p>
	            <?php else: ?>
	            <h5 class=" <?php echo e($isMobile ? 'relative-font' : ''); ?>">
	            	<?php echo e($user->getNameOrUsername()); ?>'s Posts.
	            	<span style="float:right"> Total <?php echo e($statuses->count()); ?> posts.<span>
	            		
	            	</h5>
	                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	                    <!-- Post -->
	                    <?php echo $__env->make('posts.block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	            <?php endif; ?>
			</div>

		</div>	<!-- col1 end -->

		<?php if($isDesktop): ?>
			<!-- col2 -->
			<div class="col-md-4 order-1 order-md-2 friends-section">

				<?php if(Auth()->user() != $user): ?> 
					<?php if(Auth()->user()->hasBlocked($user->id)): ?>
						<a href="/unblock/<?php echo e($user->id); ?>" class="btn btn-success float-right">UnBlock</a>
					<?php else: ?>
						<a href="/block/<?php echo e($user->id); ?>" class="btn btn-danger float-right">Block</a>
					<?php endif; ?>
				<?php endif; ?>

				<?php if(Auth()->user()): ?>
					<h3><?php echo e($user->getFirstNameOrUsername()); ?>'s Friends.</h3>
				<?php endif; ?>
				<?php if(!$user->friends()->count()): ?>
					<p><?php echo e($user->getFirstNameOrUsername()); ?> has no friends.</p>
				<?php else: ?>
					<?php $__currentLoopData = $user->friends(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php echo $__env->make('users.partials.block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			</div>	<!-- col2 end -->
		<?php endif; ?>

	</div><!-- row end -->
            <div class="row">
                <div class="col-12 d-flex justify-content-center">
                    <?php echo e($statuses->links()); ?>

                </div>
            </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/profile/index.blade.php ENDPATH**/ ?>