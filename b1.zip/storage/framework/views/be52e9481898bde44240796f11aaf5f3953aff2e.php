<?php $__env->startSection('content'); ?>

<?php if($isDesktop): ?>
	<div class="container profiles-container">

		<!-- row -->
		<div class="row mt-5">

			<!-- col1 -->
			<div class="<?php echo e($isMobile ? 'col-12' : 'col-md-8'); ?>">

				<form role="form" action="<?php echo e(route('topic.create')); ?>" method="post" class="">
		        <?php echo csrf_field(); ?>
				  <div class="form-group">
				    <label for="topicName ">Create New Topic</label><br>
				    <input type="text" name="topicName" class="form-control mr-auto w-auto d-inline shadow-cus" id="topicName" aria-describedby="" placeholder="Enter topic name" value="<?php echo e(old('topicName')); ?>" required="">

					<button type="submit" class="btn btn-primary shadow-cus">Create Topic</button>
					<?php $__errorArgs = ['topicName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                    <span class="invalid-feedback d-block" role="alert">
	                        <strong><?php echo e($message); ?></strong>
	                    </span>
	                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					<div class="clear-fix"></div>
				  </div>
				  
				</form>
				
				<ul class="list-group shadow-cus">
					<li class="active list-group-item">My Topics:</li>
					<?php $__currentLoopData = $myTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <a href="<?php echo e(route('topic.open', ['id' => $topic->id])); ?>">
					  	<li class="list-group-item">
					  		<?php echo e($topic->name); ?>

							

							<div class="float-right">
								<span class="last-post-preview text-secondary half-opacity">
									<?php echo e($topic->getLastPost() ? substr($topic->getLastPost()->body, 0, 30) : ''); ?>

								</span>


								<span class="badge bg-purple badge-pill "> <?php echo e(Auth::user()->isAdminOfTopic($topic) ? 'admin' : count($topic->posts)); ?></span> 
							</div>
					  	</li>	
					  </a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>	





				


			</div> <!-- col1 end -->

			
			<div class="<?php echo e($isMobile ? 'col-12' : 'col-md-4'); ?>">

				
			    <label for="topicName mr-auto">Search for topic</label>
			    <form class="form-inline my-2 my-lg-0 d-block" action="<?php echo e(route('search.topic')); ?>">
			    	<div class="form-group mb-3">
					    <input class="form-control mr-sm-2 shadow-cus" type="search" placeholder="Search" aria-label="Search">
					    <button class="btn btn-success my-2 my-sm-0 shadow-cus" type="submit">Search</button>
				    </div>
			    </form>


				

				<ul class="list-group shadow-cus">
					<li class="list-group-item active">Browse Topics</li>
					<div class="browse-topics">
						
					<?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <a href="<?php echo e(route('topic.open', ['id' => $topic->id])); ?>"><li class="list-group-item"><?php echo e($topic->name); ?></li></a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</ul>
				
				
			</div>
		

		<!-- Modal -->
		<div class="modal fade" id="searchTopicModal" tabindex="-1" role="dialog" aria-labelledby="searchTopicModalLabel" aria-hidden="true">
		  <div class="modal-dialog" role="document">
		    <div class="modal-content">

		      <div class="modal-header">
		        <h5 class="modal-title" id="searchTopicModalLabel">Search Topic</h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		        </button>
		      </div>

		      <div class="modal-body">

		        

		      </div>

		      </div>
		    </div>
		  </div>
		

		</div><!-- row end -->

	</div>


<?php else: ?>
<div class="row">

	<div class="col-12">
		<form role="form" action="<?php echo e(route('topic.create')); ?>" method="post">
        <?php echo csrf_field(); ?>
			<div class="form-group">
				<label for="topicName" class="relative-font">Create Topic  </label><a href="<?php echo e(route('topic.other')); ?>" class="float-right relative-font">Browse	 topics</a>
				<input type="text" name="topicName" class="form-control relative-font p-5p" id="topicName" aria-describedby="emailHelp" placeholder="Enter topic name" required="">
				<?php $__errorArgs = ['topicName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				<button type="submit" class="btn btn-primary float-right relative-font">Save</button>
				<hr class="border-dark">
				<div class="clear-fix"></div>
			</div>
		</form>

		
		<ul class="list-group">
			<li class="active list-group-item relative-font mb-2">My Topics:</li>
			<?php $__currentLoopData = $ownedTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  <a href="<?php echo e(route('topic.open', ['id' => $topic->id])); ?>"><li class="list-group-item relative-font"><?php echo e($topic->name); ?></li></a>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>

	</div>



</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/topic/index.blade.php ENDPATH**/ ?>