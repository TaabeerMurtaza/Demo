<div class="media mx-1 my-3">
    <img src="/storage/dp.png" class=" rounded mr-2" alt="Profile Picture of <?php echo e($user->getNameOrUsername()); ?>" style="max-width:70px;">
    <div class="media-body">
        <a href="<?php echo e(route('profile.index', [$user->id])); ?>"><h4 class="mt-0 mb-1 userblock_name"><?php echo e($user->getNameFirstNameOrUsername()); ?></h4></a>
        <p class="h6 user-location w-100">
            <?php if($user->getName()): ?>
                <?php echo e('@'.$user->username); ?>

            <?php endif; ?>
        </p>
        <?php if($user->isFriendWith(Auth::user())): ?><a href="<?php echo e('/chat/'.$user->id.'#end_of_chats'); ?>" class="chat-button btn btn-primary btn-sm">Send Message</a> <?php endif; ?>
    </div>
</div>
<?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/users/partials/compact.blade.php ENDPATH**/ ?>