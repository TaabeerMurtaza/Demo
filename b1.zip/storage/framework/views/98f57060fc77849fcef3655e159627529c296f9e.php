<?php $__env->startSection('content'); ?>
<!-- Custom Styles -->
<link href="<?php echo e(asset('css/custom-styles.css')); ?>" rel="stylesheet" />
<!-- End of Custom Styles -->


<div class=" <?php echo e($isMobile ?  'relative-font' : ''); ?> container-fluid">
    <div class="row">
        <div class="<?php echo e($isMobile ? 'col-12' : 'col-md-8'); ?>">
            <h3 class="bg-light p-2 rounded text-center mb-0 <?php echo e($isMobile ? 'relative-font' : ''); ?>">Recent Chats:</h3>
            <hr class="my-0">
            <div class="chat-list bg-light">
            <?php $__currentLoopData = $final; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($chat->other()): ?>
                  <a href="<?php echo e(route('chat.chat', $chat->other()->id)); ?>" class="text-dark">
                      <div class="media p-2">
                        <img src="/storage/<?php echo e($chat->other()->getDp()); ?>" class="mr-3 user-dp rounded-circle" alt="<?php echo e($chat->other()->username); ?>">
                        <div class="media-body">
                          <h5 class="mt-0 <?php echo e($isMobile ? 'relative-font' : ''); ?>"><?php echo e('@'.$chat->other()->username); ?> <span class=" small float-right"><?php echo e($chat->getdate()); ?></span></h5>

                          <span class="text-secondary d-block one-line">
                            <?php echo e($chat->body); ?>

                          </span>
                        </div>
                      </div>
                    </a>
                <?php endif; ?>
                <hr class="border-secondary">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <hr>
        </div>


          
        <?php if(!$isMobile): ?>
        
        <div class="h-75 ver_col d-none d-md-block"></div>
          <div class="d-none d-md-block col-md-4   order-1 order-md-2">
                <h3>Your friends:</h3>
      			<?php if(!$user->friends()->count()): ?>
      				<p>You have no friends.</p>
      			<?php else: ?>
      				<?php $__currentLoopData = $user->friends(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      					<?php echo $__env->make('users.partials.block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      			<?php endif; ?>
    		</div>
        <?php endif; ?>
    </div>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/chat/index.blade.php ENDPATH**/ ?>