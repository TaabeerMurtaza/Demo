
<?php $topic = empty($topic) ? false : $topic; ?>


<div class="shadow-cus bg-light rounded <?php echo e($isMobile ? 'p-2p mb-5p' : 'p-2'); ?> m-2">
<div class="media bg-none <?php if($isMobile): ?> relative-font mx-md-1 my-md-3 <?php endif; ?> w-100" id="<?php echo e($status->id); ?>">
    <div class="media-body w-100 alert alert-secondary mb-1">
        <div class="d-flex flex-row">

            
            <img src="/storage/<?php if($status->user->image): ?><?php echo e($status->user->image); ?><?php else: ?><?php echo e('dp.png'); ?><?php endif; ?>"
             class="rounded-custom mr-2 mr-lg-3 media-object post-dp h-100" alt="Profile Picture">
            
            
            <a href="<?php echo e(route('profile.index', [$status->user_id])); ?>" class="w-100">
                <h3 class="media-heading mt-0 <?php if($isMobile): ?> relative-font ml-3 mb-0 <?php else: ?> mb-1 <?php endif; ?> mb-1">
                    <span class="text-dark mb-auto">
                        <u><?php echo e('@'.$status->user->username); ?></u>
                    </span>
                </h3>
            </a>
            <?php if(Auth::user()): ?>
                <?php if($status->user_id == Auth::user()->id || Auth::user()->isAdmin()): ?> <a href="<?php echo e(route('timeline.delete', $status->id)); ?>" class="btn <?php echo e($isMobile ? 'btn-lg' : ''); ?> btn-danger float-right text-large <?php echo e($isMobile ? 'my-auto' : 'mb-auto'); ?>">Delete</a> <?php endif; ?>
            <?php endif; ?>
        </div>

            
        <div class="post-image">
            <?php if($status->head_image): ?>
                <img src="/storage/<?php echo e($status->head_image); ?>" class="w-100 mt-2">
            <?php endif; ?>
        </div>

        
        <div class="post-text mt-1 " style="max-height: 60vh; overflow-y: scroll;"><?php echo e($status->body); ?></div>
        <hr class="my-1">

        
        <ul class="list-inline d-flex <?php echo e($isMobile ? 'relative-font' : ''); ?>">
            <a href="<?php echo e(route('status.like', $status->id)); ?>">
                <li class="px-3">Like</li>
            </a>
            <li><?php echo e($status->likes()->count()); ?> <?php echo e(Str::plural("like",$status->likes()->count() )); ?></li>
            <li class="ml-auto <?php echo e($isMobile ? 'h3' : ''); ?>"><?php echo e($status->created_at->diffForHumans()); ?></li>
        </ul>


        

    </div>
</div>

<!-- Reply count -->
<?php if($status->replies()->count() > 0): ?>
    <a href="<?php echo e(route('status.open', $status->id)); ?>" class=" <?php echo e($isMobile ? 'bg-info display-4 text-light text-center' : 'btn btn-primary btn-block btn-lg'); ?> rounded px-2 w-100 d-block mb-1">
        <?php echo e($status->replies()->count()); ?> <?php echo e(Str::plural("reply",$status->replies()->count() )); ?>

    </a>
<?php endif; ?>

<!-- Post Form..... -->
<?php if(!$topic): ?>
    <form role="form" action="<?php echo e($topic ? route('topic.reply', ['post' => $status->id, 'id' => $topic->id]) :  route('timeline.reply',[ 'statusId' => $status->id])); ?>" method="post" class=" <?php echo e($isDesktop ? 'mb-2' : ''); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group <?php if($isDesktop): ?> mb-1 <?php endif; ?> <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <textarea name="reply-<?php echo e($status->id); ?>" rows="1" class="form-control <?php echo e(($isMobile) ? 'relative-font' : ''); ?>"
                placeholder="Post Reply..." required></textarea>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('reply-{$status->id}')); ?></strong>
            </span>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
        <button type="submit" class="btn btn-primary <?php echo e(($isMobile) ? 'relative-font' : ''); ?>" value="Post">Reply</button>
    </form>
<?php endif; ?>
</div><?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/posts/block.blade.php ENDPATH**/ ?>