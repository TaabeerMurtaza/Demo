<form action="<?php echo e(route('artisan.post')); ?>" method="post">
	<?php echo csrf_field(); ?>
	<input type="text" name="command">
	<input type="submit" value="submit" class="btn btn-primary">
</form><?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/artisan.blade.php ENDPATH**/ ?>