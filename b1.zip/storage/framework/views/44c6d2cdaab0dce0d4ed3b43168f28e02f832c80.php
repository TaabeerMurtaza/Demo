<?php $__env->startSection('content'); ?>
<?php if($isMobile): ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 your-friends">
                <h3 class="relative-font">Your Friends:</h3>
                <?php if(!$friends->count()): ?>
                    <p class="relative-font_5">You have no friends.</p>
                <?php else: ?>
                    <?php $__currentLoopData = $friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('users.partials.block_m', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
<hr>
            <div class="col-12 bg-light p-2 rounded relative-font friend-requests">
                <h4 class="relative-font-2">Friend requests.</h4>
                <?php if(!$requests->count()): ?>
                    <p class="relative-font_5">You have no friend requests.</p>
                <?php else: ?>
                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('users.partials.block_m', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>   
            </div>

        </div>
    </div>




<?php else: ?>
    <div class="container">
        <div class="row">
            <!-- Friends -->
            <div class="col-md-6 order-2 order-md-1">
                <h3>Your Friends.</h3>
                <?php if(!$friends->count()): ?>
    				<p>You have no friends.</p>
    			<?php else: ?>
    				<?php $__currentLoopData = $friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    					<?php echo $__env->make('users.partials.block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <hr>
            </div>
        
            <?php if($isDesktop): ?>
                <!-- Friend Requests -->
                <div class="col-md-6 order-1 order-md-2">
                    <h4>Friend requests.</h4>
                    <?php if(!$requests->count()): ?>
        				<p>You have no friend requests.</p>
        			<?php else: ?>
        				<?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        					<?php echo $__env->make('users.partials.block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        			<?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/profile/friends.blade.php ENDPATH**/ ?>