<?php $__env->startSection('content'); ?>

	<!-- Custom Styles -->
    <link href="<?php echo e(asset('css/custom-styles.css')); ?>" rel="stylesheet"/>
    <!-- End of Custom Styles -->

<div class=" <?php echo e($isMobile ? 'container-fluid' : 'container'); ?> profiles-container">

	<!-- row -->
	<div class="row mt-5 d-md-flex">
        <!-- col1 -->
		<div class="<?php echo e($isMobile ? 'col-12' : 'col-md-8'); ?> order-2 order-md-1">

            <?php if($isMobile): ?>
                        
                <div class="intro-wrapper bg-light rounded px-3 pb-5">
                    <h1 class="relative-font-2 text-primary">
                        <?php echo e($topic->name); ?>

                        <?php if(Auth()->user()->isMemberOfTopic($topic) || Auth::user()->isAdminOfTopic($topic)): ?>
                            <a href="<?php echo e(route('topic.leave', ['id' => $topic->id])); ?>" class="btn btn-danger relative-font_5 float-right">Leave Topic</a>
                        <?php else: ?>
                            <a href="<?php echo e(route('topic.join', ['id' => $topic->id])); ?>" class="btn btn-success relative-font_5 float-right">Join Topic</a>
                        <?php endif; ?>
                    </h1>
                </div>

            <?php else: ?>
                        
            <div class="media d-none d-md-flex bg-light p-2 rounded shadow-cus">

                <div class="media-body row">
                    <div class="left-part col-8">
                        <h1 class="mt-0 mb-1 h3 userblock_name text-success"><?php echo e($topic->name); ?></h1>
                    </div>


                    
                    
                </div>
            </div>
            <?php endif; ?>
            <hr class="border-dark">

            <div class="posts mt-md-5 <?php echo e($isMobile ? 'relative-font' : ''); ?>">
                
                <form role="form" action="<?php echo e(route('topic.post', ['id' => $topic->id])); ?>" method="post" enctype="multipart/form-data" class="">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group shadow-cus bg-light p-2 <?php echo e($errors->has('post')? ' has-error' : ''); ?>">
                        <label for="create_post" class=" <?php echo e($isMobile ? 'relative-font' : ''); ?>">Create a new Post</label>
                        <textarea name="post" rows="2" id='create_post' class="form-control <?php echo e(($isMobile) ? 'relative-font' : ''); ?>"
                            placeholder="What's up <?php echo e(auth()->user()->getFirstNameOrUsername()); ?>?"><?php echo e(old('post')); ?></textarea>
                        <?php if($errors->has('post')): ?>
                        <span class="help-block text-danger"><?php echo e($errors->first('post')); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group shadow-cus <?php echo e($errors->has('head_image')? ' has-error' : ''); ?>">
                        <input type="file" name="head_image" class="form-control h-auto <?php echo e(($isMobile) ? 'relative-font' : ''); ?>">
                        <?php if($errors->has('head_image')): ?>
                        <span class="help-block"><?php echo e($errors->first('head_image')); ?></span>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary <?php echo e(($isMobile) ? 'relative-font' : ''); ?>" value="Post">Post</button>
                </form>

                <?php if(!($posts->count())): ?>
                    <p>There's no post on this topic.</p>
                <?php else: ?>
                <h5 class=" <?php echo e($isMobile ? 'relative-font' : ''); ?>">
                    Posts on topic <?php echo e($topic->name); ?>

                    <span style="float:right"> Total <?php echo e($posts->count()); ?> posts.<span>
                        
                    </h5>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <!-- Post -->
                        <?php echo $__env->make('posts.block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>

        </div> <!-- col1 end -->

        <?php if($isDesktop): ?>
            <!-- col2 -->
            <div class="col-md-4 order-1 order-md-2 friends-section">
                <?php if(Auth()->user()->isMemberOfTopic($topic) || Auth::user()->isAdminOfTopic($topic)): ?>
                    <div class="d-block">
                        <a href="<?php echo e(route('topic.leave', ['id' => $topic->id])); ?>" class="btn btn-danger float-right">Leave Topic</a>
                        <div class="clear-fix"></div>
                    </div>
                <?php else: ?>
                    <div class="d-block">
                        <a href="<?php echo e(route('topic.join', ['id' => $topic->id])); ?>" class="btn btn-success float-right">Join Topic</a>
                        <div class="clear-fix"></div>
                    </div>
                <?php endif; ?>
                <hr>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('users.partials.block_topic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>  <!-- col2 end -->
        <?php endif; ?>


	</div><!-- row end -->

    <div class="row">
        <div class="col-12 d-flex justify-content-center">
            <?php echo e($posts->links()); ?>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/topic/posts.blade.php ENDPATH**/ ?>