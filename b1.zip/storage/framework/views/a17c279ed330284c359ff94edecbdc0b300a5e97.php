<?php $__env->startSection('content'); ?>

<div class="container">
    <h2> <?php echo e($users->count()); ?> results found for "<?php echo e(Request::input('query')); ?>"</h2>

    <div class="row">
        <div class="col-12">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$user): ?>
                    <h3>Sorry no results found...</h3>
                <?php else: ?>
                    <?php echo $__env->make('users.partials.block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/search/results.blade.php ENDPATH**/ ?>