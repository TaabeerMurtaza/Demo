<div class="media mx-1 my-3 shadow-cus bg-light p-2">

    <img src="/storage/dp.png" class=" rounded mr-2" alt="Profile Picture of <?php echo e($user->getNameOrUsername()); ?>" style="max-width:20%;">
    <div class="media-body">
        <a href="<?php echo e(route('profile.index', [$user->id])); ?>"><h5 class="mt-0 mb-1 userblock_name relative-font"><?php echo e($user->getNameOrUsername()); ?></h5></a>
        <p class="h6 user-location w-100 relative-font_5"><?php echo e($user->location); ?></p>
        <?php if($user->isFriendWith(Auth::user())): ?>
            <a href="<?php echo e('/chat/'.$user->id.'#end_of_chats'); ?>" class="chat-button btn btn-primary btn-sm relative-font_5">Send Message</a>
        <?php elseif(Auth()->user()->hasFriendRequestPending($user)): ?>
            <a href="/friends/accept/<?php echo e($user->id); ?>" class="btn btn-primary relative-font">Accept friend request</a>

        <?php endif; ?>
        <?php if(Auth()->user()->isFriendWith($user)): ?>
            <a href="<?php echo e(route('friends.delete',['user'=> $user])); ?>" class="btn btn-danger btn-sm relative-font_5 float-right">Delete Friend</a>
        <?php endif; ?>
    </div>

</div>
<?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/users/partials/block_m.blade.php ENDPATH**/ ?>