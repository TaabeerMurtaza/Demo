<?php if(Session::has('info')): ?>
<div class="alert alert-success shadow-cus text-center mx-1 mx-md-5" role="alert">
	<div class="container <?php echo e($isMobile ? 'display-4' : 'h3'); ?>">
		<?php echo e(Session::get('info')); ?>

	</div>
</div>
<?php endif; ?><?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/template/partials/alerts.blade.php ENDPATH**/ ?>