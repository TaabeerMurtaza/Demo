<?php $__env->startSection('content'); ?>

	<!-- Custom Styles -->
    <link href="<?php echo e(asset('css/custom-styles.css')); ?>" rel="stylesheet"/>
    <!-- End of Custom Styles -->

<div class="<?php echo e(($isMobile) ? 'relative-font container-fluid' : 'container'); ?> profiles-container">

	<!-- row -->
	<div class="row mt-5 d-md-flex">
		<!-- col1 -->
		<div class=" <?php if($isMobile): ?> col-12 <?php else: ?> col-md-8 order-2 order-md-1 <?php endif; ?>">

            <h3>All is well</h3>

		</div>	<!-- col1 end -->

		<!-- col2 -->
		<div class="d-none d-md-block col-md-4 order-1 order-md-2 friends-section">
			

		</div>	<!-- col2 end -->


	</div><!-- row end -->

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/online/index.blade.php ENDPATH**/ ?>