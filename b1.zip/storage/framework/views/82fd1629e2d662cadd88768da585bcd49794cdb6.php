	<nav class="navbar navbar-expand-lg sticky-top navbar-dark text-light bg-dark mb-3">
	    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
	        Hasola
	    </a>
	    <button aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler <?php if($US_noti | $US_chats | $US_freqs): ?> border-light custom-nav-toggler <?php endif; ?>" data-target="#navbarSupportedContent" data-toggle="collapse" type="button">
            <span class="navbar-toggler-icon">
                <?php if($US_noti | $US_chats | $US_freqs): ?> <span class="custom-star">*</span> <?php endif; ?>
	        </span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarSupportedContent">
	        
	        <form class="form-inline my-2 my-lg-0 mr-auto" role="search" action="<?php echo e(route('search.results')); ?>">
	            <input aria-label="Search" class="form-control mr-sm-2" placeholder="Search users" type="search" name="query">
	                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
	                    Search
	                </button>
	        </form>
	        
	        <ul class="navbar-nav">
                <?php if(Auth::check()): ?>
	            <li class="nav-item">
	                <a class="nav-link" href="<?php echo e(route('timeline')); ?>">
	                    <span class="">Timeline</span>
	                </a>
                </li>
                <li class="nav-item">
	                <a class="nav-link" href="<?php echo e(route('chat.index', Auth::user()->id)); ?>">
                        <span class="<?php if( $US_chats ): ?> font-weight-bold text-light <?php endif; ?>">
                            Chat
                            <span class="">
                            	<?php if( $US_chats ) echo '*'; ?>
                            </span>
                        </span>
	                </a>
	            </li>
	            <li class="nav-item">
	                <a class="nav-link " href="<?php echo e(route('topic.index')); ?>">
	                    <span class="<?php echo e(false ? 'font-weight-bold text-light' : ''); ?>">
	                    	Topics
	                    </span>
	                </a>
	            </li>
	            <li class="nav-item">
	                <a class="nav-link " href="<?php echo e(route('friends.index')); ?>">
	                    <span class="<?php echo e($US_freqs ? 'font-weight-bold text-light' : ''); ?>">
	                    	Friends
	                    	<?php echo e($US_freqs ? '*' : ''); ?>

	                    </span>
	                </a>
	            </li>
                <li class="nav-item">
	                <a class="nav-link" href="<?php echo e(route('notification.index', Auth::user()->id)); ?>">
                        <span class="<?php if($US_noti): ?> font-weight-bold text-light <?php endif; ?>">
                            Notifications
                            <span class="">
                            	<?php if( $US_noti ) echo '*'; ?>
                            </span>
                        </span>
	                </a>
	            </li>
	            <?php endif; ?>
	        </ul>

	        
	        <ul class="navbar-nav ml-auto">
	            <?php if(Auth::check()): ?>
	            <li class="nav-item">
	                <a class="nav-link" href="<?php echo e(route('profile')); ?>">
	                    <?php echo e(Auth::user()->getFirstNameOrUsername()); ?>

	                </a>
	            </li>
	            <li class="nav-item">
	                <a class="nav-link" href="<?php echo e(route('logout')); ?>">
	                    Sign Out
	                </a>
	            </li>
	            <?php else: ?>
	            <li class="nav-item">
	                <a class="nav-link" href="<?php echo e(route('login')); ?>">
	                    Sign in
	                </a>
	            </li>
	            <li class="nav-item">
	                <a class="nav-link" href="<?php echo e(route('register')); ?>">
	                    Register
	                </a>
	            </li>
	            <?php endif; ?>
	        </ul>
	    </div>
	</nav>
<?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/template/partials/navbar.blade.php ENDPATH**/ ?>