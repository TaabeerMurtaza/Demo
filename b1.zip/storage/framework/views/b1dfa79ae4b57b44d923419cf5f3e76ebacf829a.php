<?php $__env->startSection('content'); ?>

	<!-- Custom Styles -->
    <link href="<?php echo e(asset('css/custom-styles.css')); ?>" rel="stylesheet"/>
    <!-- End of Custom Styles -->
<?php if($isDesktop): ?>
	<div class=" <?php echo e($isMobile ? 'container-fluid' : 'container'); ?> profiles-container">

		<!-- row -->
		<div class="row mt-5 d-md-flex">

		
		<div class="<?php echo e($isMobile ? 'col-12' : 'col-md-12 '); ?> p-2 ">
			<form class="form-inline my-2 my-lg-0" role="search" action="<?php echo e(route('search.topic')); ?>">
		        <input aria-label="Search" class="form-control mr-sm-2" placeholder="Search Topics" type="search" name="query">
		        <button class="btn btn-success my-2 my-sm-0" type="submit">
		            Search
		        </button>
		    </form>
		</div>

			<!-- col1 -->
			<div class="<?php echo e($isMobile ? 'col-12' : 'col-md-12'); ?>">

				
				<ul class="list-group">
					<li class="active list-group-item">Search Results:</li>
					<?php $__currentLoopData = $searched_topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <a href="<?php echo e(route('topic.open', ['id' => $topic->id])); ?>"><li class="list-group-item"><?php echo e($topic->name); ?></li></a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>	

			</div> <!-- col1 end -->

		</div><!-- row end -->

	</div>

<?php else: ?>

<div class="row">
	<div class="col-12">
		
		<form class="form-inline my-2 my-lg-0 mr-auto re" role="search" action="<?php echo e(route('search.topic')); ?>">
	        <input aria-label="Search" class="form-control mr-sm-2 relative-font p-5p" placeholder="Search Topics" type="search" name="query">
	        <?php $__errorArgs = ['topicName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	        <button class="btn btn-success my-2 my-sm-0 relative-font" type="submit">
	            Search
	        </button>
	    </form>
		

		
		<ul class="list-group">
			<li class="active list-group-item relative-font">Search Results:</li>
			<?php $__currentLoopData = $searched_topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  <a href="<?php echo e(route('topic.open', ['id' => $topic->id])); ?>"><li class="list-group-item relative-font"><?php echo e($topic->name); ?></li></a>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>	


	</div>
</div>



<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/topic/search.blade.php ENDPATH**/ ?>