<?php $__env->startSection('content'); ?>
<!-- Custom Styles -->
<link href="<?php echo e(asset('css/custom-styles.css')); ?>" rel="stylesheet" />
<!-- End of Custom Styles -->
<div class="<?php if($isMobile): ?> flex-container mx-1 relative-font <?php else: ?> container <?php endif; ?>">
    <div class="row">
        <div class="<?php if($isMobile): ?> col-12 <?php else: ?> col-lg-10 <?php endif; ?> bg-light shadow-cus p-2 rounded">
            <?php if(Auth::check()): ?>
                <form role="form" action="<?php echo e(route('timeline.update')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group <?php echo e($errors->has('status')? ' has-error' : ''); ?>">
                        <textarea name="status" rows="2" class="form-control <?php echo e(($isMobile) ? 'relative-font' : ''); ?>"
                            placeholder="What's up <?php echo e(auth()->user()->getFirstNameOrUsername()); ?>?"><?php echo e(old('status')); ?></textarea>
                        <?php if($errors->has('status')): ?>
                        <span class="help-block text-danger font-weight-bold"><?php echo e($errors->first('status')); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group <?php echo e($errors->has('head_image')? ' has-error' : ''); ?>">
                        <input type="file" name="head_image" class="form-control h-auto <?php echo e(($isMobile) ? 'relative-font' : ''); ?>">
                        <?php if($errors->has('head_image')): ?>
                        <span class="help-block"><?php echo e($errors->first('head_image')); ?></span>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary <?php echo e(($isMobile) ? 'relative-font' : ''); ?>" value="Post">Post</button>
                </form>
            <?php endif; ?>
            <hr>
        </div>
    </div>
    <div class="row">
        <div class="<?php if($isMobile): ?> col-12 <?php else: ?> col-lg-8 col-xl-8 <?php endif; ?> text-md-justify ">
            <?php if(!($statuses->count())): ?>
            <p>There's no post to show on your timeline...</p>
            <?php else: ?>
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <!-- Post -->
            <?php echo $__env->make('posts.block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        
        <?php if($isDesktop): ?>
            <div class="col-4 mt-2">
                
                <ul class="list-group shadow-cus">
                    <li class="active list-group-item">My Topics:</li>
                    <?php if($myTopics): ?>
                        <?php $__currentLoopData = $myTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <a href="<?php echo e(route('topic.open', ['id' => $topic->id])); ?>">
                            <li class="list-group-item">
                                <?php echo e(( strcspn($topic->name, '!@#^%$#') > 20 ) ? ( substr($topic->name, 0, 20).'...' ) : $topic->name); ?>


                                <div class="float-right">
                                    <span class="badge bg-purple badge-pill "> <?php echo e(Auth::user()->isAdminOfTopic($topic) ? 'admin' : count($topic->posts)); ?></span> 
                                </div>
                            </li>   
                          </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </div>
        <?php endif; ?>

    </div>
    <div class="row">
        <div class="col-12 d-flex justify-content-center">
            <?php echo e($statuses->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/posts/index.blade.php ENDPATH**/ ?>