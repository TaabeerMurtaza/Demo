<?php $__env->startSection('content'); ?>
<!-- Custom Styles -->
<link href="<?php echo e(asset('css/custom-styles.css')); ?>" rel="stylesheet" />

<!-- End of Custom Styles -->


<div class="<?php echo e(($isMobile) ? ' container-fluid relative-font' : 'container'); ?>">
    <div class="row">
        <div class="h-100 <?php echo e($isMobile ? 'col-12' : 'col-lg-9'); ?>">
            <div class="chats-wrapper bg-light border my-2">
                <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($chat->user_id == $other->id): ?>

                      
                      <div class="media my-2 p-1 ">
                        <img src="/storage/<?php echo e($chat->other()->getDp()); ?>" class="mr-3 <?php echo e($isMobile ? 'chat-dp-2' : 'chat-dp'); ?> rounded-circle" alt="<?php echo e($chat->other()->getFirstNameOrUsername()); ?>">
                        <div class="media-body">
                            <h6 class="rounded bg-secondary p-2 pr-auto text-light w-75 mb-0 chat-body <?php echo e($isMobile ? 'relative-font' : ''); ?>">
                                <?php echo e($chat->body); ?>

                            </h6>
                            <span class="time small text-secondary float-left"><?php echo e($chat->getTime()); ?></span>
                          </div>
                        </div>
                    
                    <?php else: ?>

                      
                      <div class="media my-2 p-1 ">
                        <div class="media-body">
                            <div class="float-right w-75">
                                <h6 class="rounded bg-info p-2 pr-auto text-light chat-body <?php echo e($isMobile ? 'relative-font' : ''); ?> mb-0">
                                    <?php echo e($chat->body); ?>

                                </h6>
                                <span class="time small text-secondary float-left"><?php echo e($chat->getTime()); ?></span>
                            </div>
                        </div>

                        </div>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- Custom Javascript -->
                <script>
                    $(document).ready(function() {
                    $.ajaxSetup({
                        headers: {
                          'X-CSRF-Token': $('meta[name="_token"]').attr('content')
                        }
                      });
                    });
                    xhttp.onreadystatechange = function() {
                      if (xhttp.readyState == 4 && xhttp.status == 200) {
                        document.getElementById("msg").innerHTML = xhttp.responseText;
                      }
                    };
                    xhttp.open("GET", "fetch_msgs.php", true);
                    xhttp.send();
                </script>
                <!-- End of custom JS -->
                <hr id="end_of_chats">
            </div>


            <form role="form" action="<?php echo e(route('chat.post', $other)); ?>" method="post" enctype="multipart/form-data" class="bg-light shadow-cus p-2 rounded">
                <?php echo csrf_field(); ?>
                
                <div class="form-group <?php echo e($errors->has('msg')? ' has-error' : ''); ?>">
                    <input name="msg" class="form-control needs-validation <?php echo e($isMobile ? 'relative-font p-5p' : ''); ?>"
                        placeholder="What's up <?php echo e(auth()->user()->getFirstNameOrUsername()); ?>?" required>
                    <?php if($errors->has('msg')): ?>
                    <span class="help-block"><?php echo e($errors->first('msg')); ?></span>
                    <?php endif; ?>
                </div>
                
                <div class="form-group <?php echo e($errors->has('head_image')? ' has-error' : ''); ?>">
                    <input type="file" name="head_image" class="form-control needs-validation h-100 <?php echo e($isMobile ? 'relative-font' : ''); ?>">
                    <?php if($errors->has('head_image')): ?>
                    <span class="help-block"><?php echo e($errors->first('head_image')); ?></span>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary <?php echo e($isMobile ? 'relative-font mb-5p' : ''); ?>" value="Post">Post</button>
            </form>

            
            <script>

                (function() {
                  'use strict';
                  window.addEventListener('load', function() {
                    // Fetch all the forms we want to apply custom Bootstrap validation styles to
                    var forms = document.getElementsByClassName('needs-validation');
                    // Loop over them and prevent submission
                    var validation = Array.prototype.filter.call(forms, function(form) {
                      form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                          event.preventDefault();
                          event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                      }, false);
                    });
                  }, false);
                })();
            </script>


        </div>

        
        <div class="d-none d-lg-block col-lg-3 order-1 order-md-2">
            <h3>Your friends:</h3>
			<?php if(!Auth::user()->friends()->count()): ?>
				<p>You have no friends.</p>
			<?php else: ?>
				<?php $__currentLoopData = Auth::user()->friends(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo $__env->make('users.partials.compact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/chat/chat.blade.php ENDPATH**/ ?>