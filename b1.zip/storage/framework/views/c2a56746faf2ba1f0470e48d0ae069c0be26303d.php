<?php $__env->startSection('content'); ?>
<!-- Custom Styles -->
<link href="<?php echo e(asset('css/custom-styles.css')); ?>" rel="stylesheet" />
<!-- End of Custom Styles -->

<div class="<?php echo e($isMobile ? 'container-fluid' : 'container'); ?>">
    <div class="row">
        <div class="col-lg-10 shadow-cus bg-light <?php echo e($isMobile ? 'relative-font' : ''); ?> p-2 rounded">
            <h3 class="<?php echo e($isMobile ? 'h1 font-weight-bold text-uppercase' : ''); ?>">Notifications</h3>
            <hr>
            
                <a href="<?php echo e(route('notification.read')); ?>" class="mar-read btn btn-primary <?php echo e($isMobile ? 'btn-lg btn-block ' : ''); ?>  mb-1 mb-md-3">
                    <?php echo $isMobile ? '<h1 class="display-4">' : ''; ?>
                        Mark as read
                    <?php echo $isMobile ? '</h1>' : ''; ?></a>
            
            <ul class="list-group">
                <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('notification.open',$noti->id)); ?>"><li class="list-group-item my-1 <?php echo  ($noti->seen)?'text-dark':''; ?>"><?php echo e($noti->body); ?></li></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>

    <div class="row">
        <div class="col-12 d-flex justify-content-center">
            <hr>
            <?php echo e($notes->links()); ?> 
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/notification/index.blade.php ENDPATH**/ ?>