<?php $__env->startSection('content'); ?>

<div class="<?php echo e(($isMobile) ? 'relative-font container-fluid' : 'container'); ?> profiles-container">

	<!-- row -->
	<div class="row mt-5 d-md-flex">
		<!-- col1 -->
		<div class=" <?php if($isMobile): ?> col-12 <?php else: ?> col-md-8 order-2 order-md-1 <?php endif; ?>">

            
			<div class="shadow-cus bg-light rounded <?php echo e($isMobile ? 'p-2p mb-5p' : 'p-2'); ?> m-2">
                <div class="media bg-none <?php if($isMobile): ?> relative-font mx-md-1 my-md-3 <?php endif; ?> w-100" id="<?php echo e($status->id); ?>">
                    <div class="media-body alert alert-secondary mb-1">
                        <div class="d-flex flex-row">

                            
                            <img src="/storage/<?php if($status->user->image): ?><?php echo e($status->user->image); ?><?php else: ?><?php echo e('dp.png'); ?><?php endif; ?>"
                             class="rounded-custom mr-2 mr-lg-3 media-object post-dp h-100" alt="Profile Picture">

                            <a href="<?php echo e(route('profile.index', [$status->user_id])); ?>" class="w-100">
                                <h3 class="media-heading mt-0 <?php if($isMobile): ?> relative-font ml-3 mb-0 <?php else: ?> mb-1 <?php endif; ?> mb-1">
                                    <span class="text-dark mb-auto">
                                        <u><?php echo e('@'.$status->user->username); ?></u>
                                    </span>
                                </h3>
                            </a>
                            <?php if($status->user_id == Auth::user()->id || Auth::user()->isAdmin()): ?> <a href="<?php echo e(route('timeline.delete', $status->id)); ?>" class="btn <?php echo e($isMobile ? 'btn-lg' : ''); ?> btn-danger float-right text-large <?php echo e($isMobile ? 'my-auto' : 'mb-auto'); ?>">Delete</a> <?php endif; ?>
                        </div>

                            
                        <div class="post-image">
                            <?php if($status->head_image): ?>
                                <img src="/storage/<?php echo e($status->head_image); ?>" class="w-100 mt-2">
                            <?php endif; ?>

                            
                        </div>

                        
                        <div class="post-text mt-1 "><?php echo e($status->body); ?></div>
                        <hr class="my-1">

                        
                        <ul class="list-inline d-flex <?php echo e($isMobile ? 'h3' : ''); ?>">
                            <a href="<?php echo e(route('status.like', $status->id)); ?>">
                                <li class="px-3">Like</li>
                            </a>
                            <li><?php echo e($status->likes()->count()); ?> <?php echo e(Str::plural("like",$status->likes()->count() )); ?></li>
                            <li class="ml-auto "><?php echo e($status->created_at->diffForHumans()); ?></li>
                        </ul>


                        

                    </div>
                </div>

                <!-- Reply count -->
                <?php if($status->replies()->count() > 0): ?>
                    <span class=" <?php echo e($isMobile ? 'bg-info display-4 text-light text-center' : ''); ?> rounded px-2 w-100 d-block mb-1">
                        <?php echo e($status->replies()->count()); ?> <?php echo e(Str::plural("reply",$status->replies()->count() )); ?>

                    </span>
                <?php endif; ?>

                <!-- Post Form..... -->
                <form role="form" action="<?php echo e(route('timeline.reply',[ 'statusId' => $status->id])); ?>" method="post" class=" <?php echo e($isDesktop ? 'mb-2' : ''); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group <?php if($isDesktop): ?> mb-1 <?php endif; ?> <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <textarea name="reply-<?php echo e($status->id); ?>" rows="1" class="form-control <?php echo e(($isMobile) ? 'relative-font' : ''); ?>"
                            placeholder="Post Reply..." required></textarea>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('reply-{$status->id}')); ?></strong>
                        </span>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                    <button type="submit" class="btn btn-primary <?php echo e(($isMobile) ? 'relative-font' : ''); ?>" value="Post">Reply</button>
                </form>
                </div>

    			<div class="posts mt-md-3 <?php echo e(($isMobile) ? 'relative-font ' : ''); ?>">
    			<?php if(!($status)): ?>
                    <p>Status not Found</p>
                <?php else: ?>


                <hr>

<!-- Replies -->
<?php $__currentLoopData = $replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="shadow-cus bg-light rounded <?php echo e($isMobile ? 'p-2p mb-5p' : 'p-2'); ?> m-2">
        <div class="media mx-1 my-3" id="<?php echo e($reply->id); ?>">
            <div class="media-body w-100">

                
                <img src="/storage/<?php if($reply->user->image): ?><?php echo e($reply->user->image); ?><?php else: ?><?php echo e('dp.png'); ?><?php endif; ?>" class="w-100 rounded mr-2 mr-lg-3 mb-2 media-object reply-dp" alt="Profile Picture">
                
                <a href="<?php echo e(route('profile.index', [$reply->user_id])); ?>"><?php echo e($reply->user->getNameOrUsername()); ?>

                    <?php if($reply->user_id == Auth::user()->id || Auth::user()->isAdmin()): ?> <a href="<?php echo e(route('timeline.delete', $reply->id)); ?>" class="btn-lg btn-danger float-right text-large">Delete</a> <?php endif; ?>
                </a>

                
                <div class="reply-text alert alert-secondary w-100" style="line-break:anywhere !important; "><?php echo e($reply->body); ?></div>

                <hr>

                
                <ul class="list-inline d-flex <?php echo e($isMobile ? 'h3' : ''); ?>">
                    <a href="<?php echo e(route('status.like', $reply->id)); ?>">
                        <li class="px-3">Like</li>
                    </a>
                    <li><?php echo e($reply->likes()->count()); ?> <?php echo e(Str::plural("like",$reply->likes()->count() )); ?></li>
                    <li class="ml-auto "><?php echo e($reply->created_at->diffForHumans()); ?></li>
                </ul>

            </div>
        </div>

    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <?php endif; ?>
			</div>

		</div>	<!-- col1 end -->

		<!-- col2 -->
		<div class=" <?php echo e($isMobile ? 'd-none ' : 'd-md-block'); ?> col-md-4 order-1 order-md-2 ">
			<h3><?php echo e(count($partis)); ?> <?php echo e(Str::plural("Participant",count($partis) )); ?></h3>

			<?php if(!count($partis)): ?>
				<p>This post has no participants.</p>
			<?php else: ?>
				<?php $__currentLoopData = $partis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo $__env->make('users.partials.block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>	<!-- col2 end -->


	</div><!-- row end -->

</div>
   <div class="row w-100 <?php echo e($isMobile ? 'mb-5p' : ''); ?>">
        <div class="col-12 d-flex justify-content-center <?php echo e($isMobile ? 'display-4 mb-3' : ''); ?> ">
            <?php echo e($replies->links()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/taabeer/webdevelopment/merged/resources/views/posts/solo.blade.php ENDPATH**/ ?>