<?php

echo 'All ok';

?>