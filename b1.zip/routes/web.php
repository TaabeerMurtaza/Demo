<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


use Illuminate\Support\Facades\Artisan;
use Illuminate\Http\Request;
use App\Topic;
use App\User;

// Auth::routes();

// Home Route
Route::get('/', 'HomeController@index')->name('home');

// Registration Routes
Route::get('/register', 'RegisterController@getSignUp' )->name('register');
Route::post('/register', 'RegisterController@postSignUp' );
Route::get('/logout', 'RegisterController@SignOut' )->name('logout');


// Login Routes
Route::get('/login', 'RegisterController@getSignIn' )->name('login');
Route::post('/login', 'RegisterController@postSignIn' );

// Timeline Route
Route::get('/timeline', 'PostsController@index' )->name('timeline');
Route::post('/timeline', 'PostsController@postStatus' )->name('timeline.update')->middleware('auth');
Route::post('/timeline/{statusId}/reply', 'PostsController@postReply' )->name('timeline.reply')->middleware('auth');
Route::get('/timeline/{statusId}/delete', 'PostsController@postDelete' )->name('timeline.delete')->middleware('auth');
Route::get('/timeline/{statusId}/like', 'PostsController@getLike' )->name('status.like')->middleware('auth');
Route::get('/timeline/{statusId}/open', 'PostsController@getOpen' )->name('status.open')->middleware('auth');


// Friends Route

Route::get('/friends/add/{user}', 'FriendsController@getAdd' )->name('friends.add')->middleware('auth');
Route::get('/friends/delete/{user}', 'FriendsController@getDelete' )->name('friends.delete')->middleware('auth');
Route::get('/friends/accept/{user}', 'FriendsController@getAccept' )->name('friends.accept')->middleware('auth');
// Route::get('/friends/list/{user}', 'FriendsController@getFriendsList' )->name('friends.list');
Route::get('/friends', 'FriendsController@index' )->name('friends.index')->middleware('auth');


// Profile Routes
					// Update Profile
Route::get('/profile/edit', 'ProfilesController@edit' )->name('profile.edit')->middleware('auth');
Route::put('/profile/edit', 'ProfilesController@update' )->name('profile.update')->middleware('auth');

					// General Profile Routes
Route::get('/profile/{user}', 'ProfilesController@index' )->name('profile.index')->middleware('auth');
Route::get('/profile', function ()
	{
		return redirect()->route('profile.index',Auth::user()->id);
	})->name('profile')->middleware('auth');


// Search Routes

Route::get('/search/topics', 'SearchController@getTopicResults' )->name('search.topic')->middleware('auth');
Route::get('/search', 'SearchController@getResults' )->name('search.results')->middleware('auth');


// Chat route

Route::get('/chat/index/{user}', 'ChatsController@index')->name('chat.index')->middleware('auth');
Route::get('/chat/{user}', 'ChatsController@chat')->name('chat.chat')->middleware('auth');
Route::post('/chat/{user}', 'ChatsController@post')->name('chat.post')->middleware('auth');


// Notifications route

Route::get('/notification/open/{noti}', 'NotificationsController@open')->name('notification.open')->middleware('auth');
Route::get('/notification/read', 'NotificationsController@read')->name('notification.read')->middleware('auth');
Route::get('/notification/{user}', 'NotificationsController@index')->name('notification.index')->middleware('auth');



// Topic routes
Route::get('/topics', 'TopicController@index')->name('topic.index')->middleware('auth');
Route::post('/topics/create', 'TopicController@create')->name('topic.create')->middleware('auth');
Route::get('/topics/other', 'TopicController@other')->name('topic.other')->middleware('auth');
Route::get('/topics/{id}', 'TopicController@open')->name('topic.open')->middleware('auth');
Route::get('/topics/{id}/join', 'TopicController@join')->name('topic.join')->middleware('auth');
Route::get('/topics/{id}/leave', 'TopicController@leave')->name('topic.leave')->middleware('auth');
Route::get('/topics/{user}/{id}/kick', 'TopicController@kickOut')->name('topic.kick')->middleware('auth');
Route::post('/topics/{id}/post', 'TopicController@post')->name('topic.post')->middleware('auth');

		// Reply not allowed on Topic posts
// Route::post('/topics/{post}/{id}/reply', 'TopicController@reply')->name('topic.reply')->middleware('auth');



// Block routes
Route::get('/block/{user}', 'BlockController@block')->name('block.block')->middleware('auth');
Route::get('/unblock/{user}', 'BlockController@unblock')->name('block.unblock')->middleware('auth');
Route::get('/blocked', 'BlockController@blocked')->name('block.blocked')->middleware('auth');



// Online routes

Route::get('/online/index', function ()
{
	return view('online.index');
});


// Load Text
Route::get('/loadtext', function ()
{
	echo 'all is good';
});

// Configuration routes
Route::get('/config', function ()
{
	$result = Artisan::call('migrate');
	return $result.'<br>'.$result2.'<br>'.$result3;

})->name('config');
 
// Artisan route
Route::get('/artisan', function ()
{
	return view('artisan');
})->name('artisan');
Route::post('/artisan/post', function (Request $req)
{
	return Artisan::call($req->input('command')).' | command run: '.$req->input('command');
})->name('artisan.post');



// Test Route
Route::get('/test', function()
{
	$user = Auth::user();
    $post = $user->posts()->create([
                'body' => 'Hi everybody
I am new here
 I just joined this awesome new comunity
Lets make this day awesome',
        ]);
    $admin = User::where('id', 1)->first();
    $reply = $admin->posts()->create([
    	'body' => 'nothings djafkldjsafl',
    	'parent_id' => $post->id
    ]);
    $post->replies()->save($reply);
    return redirect('/');


} )->name('test');
