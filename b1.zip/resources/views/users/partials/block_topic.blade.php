<div class="media mx-1 my-3 shadow-cus bg-light p-2">

    <img src="/storage/dp.png" class=" rounded mr-2" alt="Profile Picture of {{ $user->getNameOrUsername() }}" style="max-width:70px;">
    <div class="media-body">
        <a href="{{route('profile.index', [$user->id]) }}"><h5 class="mt-0 mb-1 userblock_name">{{ $user->getNameOrUsername() }}</h5></a>
        <p class="h6 user-location w-100">{{ $user->location }}</p>
        @if(Auth::user()->isAdminOfTopic($topic) && $user->id != Auth::user()->id)
            <a href="{{ route('topic.kick', ['user' => $user->id, 'id' => $topic->id]) }}" class="chat-button btn btn-danger btn-sm">kickout</a>
        @endif
    </div>

</div>
