<div class="media mx-1 my-3 shadow-cus bg-light p-2">

    <img src="/storage/dp.png" class=" rounded mr-2" alt="Profile Picture of {{ $user->getNameOrUsername() }}" style="max-width:20%;">
    <div class="media-body">
        <a href="{{route('profile.index', [$user->id]) }}"><h5 class="mt-0 mb-1 userblock_name relative-font">{{ $user->getNameOrUsername() }}</h5></a>
        <p class="h6 user-location w-100 relative-font_5">{{ $user->location }}</p>
        @if($user->isFriendWith(Auth::user()))
            <a href="{{'/chat/'.$user->id.'#end_of_chats' }}" class="chat-button btn btn-primary btn-sm relative-font_5">Send Message</a>
        @elseif(Auth()->user()->hasFriendRequestPending($user))
            <a href="/friends/accept/{{$user->id}}" class="btn btn-primary relative-font">Accept friend request</a>

        @endif
        @if(Auth()->user()->isFriendWith($user))
            <a href="{{route('friends.delete',['user'=> $user])}}" class="btn btn-danger btn-sm relative-font_5 float-right">Delete Friend</a>
        @endif
    </div>

</div>
