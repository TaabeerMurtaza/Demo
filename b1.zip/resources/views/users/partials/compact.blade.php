<div class="media mx-1 my-3">
    <img src="/storage/dp.png" class=" rounded mr-2" alt="Profile Picture of {{ $user->getNameOrUsername() }}" style="max-width:70px;">
    <div class="media-body">
        <a href="{{route('profile.index', [$user->id]) }}"><h4 class="mt-0 mb-1 userblock_name">{{ $user->getNameFirstNameOrUsername() }}</h4></a>
        <p class="h6 user-location w-100">
            @if($user->getName())
                {{ '@'.$user->username }}
            @endif
        </p>
        @if($user->isFriendWith(Auth::user()))<a href="{{'/chat/'.$user->id.'#end_of_chats' }}" class="chat-button btn btn-primary btn-sm">Send Message</a> @endif
    </div>
</div>
