@extends('template.partials.default')

@section('content')

<div class="container">

</div>

@endsection
