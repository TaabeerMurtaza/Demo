@if(Session::has('info'))
<div class="alert alert-success shadow-cus text-center mx-1 mx-md-5" role="alert">
	<div class="container {{ $isMobile ? 'display-4' : 'h3' }}">
		{{ Session::get('info') }}
	</div>
</div>
@endif