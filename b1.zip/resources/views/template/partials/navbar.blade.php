	<nav class="navbar navbar-expand-lg sticky-top navbar-dark text-light bg-dark mb-3">
	    <a class="navbar-brand" href="{{ route('home') }}">
	        Hasola
	    </a>
	    <button aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler @if($US_noti | $US_chats | $US_freqs) border-light custom-nav-toggler @endif" data-target="#navbarSupportedContent" data-toggle="collapse" type="button">
            <span class="navbar-toggler-icon">
                @if($US_noti | $US_chats | $US_freqs) <span class="custom-star">*</span> @endif
	        </span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarSupportedContent">
	        {{-- Left side of NavBar --}}
	        <form class="form-inline my-2 my-lg-0 mr-auto" role="search" action="{{ route('search.results') }}">
	            <input aria-label="Search" class="form-control mr-sm-2" placeholder="Search users" type="search" name="query">
	                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
	                    Search
	                </button>
	        </form>
	        {{-- Middle part of NavBar --}}
	        <ul class="navbar-nav">
                @if(Auth::check())
	            <li class="nav-item">
	                <a class="nav-link" href="{{ route('timeline') }}">
	                    <span class="">Timeline</span>
	                </a>
                </li>
                <li class="nav-item">
	                <a class="nav-link" href="{{ route('chat.index', Auth::user()->id) }}">
                        <span class="@if( $US_chats ) font-weight-bold text-light @endif">
                            Chat
                            <span class="">
                            	<?php if( $US_chats ) echo '*'; ?>
                            </span>
                        </span>
	                </a>
	            </li>
	            <li class="nav-item">
	                <a class="nav-link " href="{{ route('topic.index') }}">
	                    <span class="{{ false ? 'font-weight-bold text-light' : '' }}">
	                    	Topics
	                    </span>
	                </a>
	            </li>
	            <li class="nav-item">
	                <a class="nav-link " href="{{ route('friends.index') }}">
	                    <span class="{{ $US_freqs ? 'font-weight-bold text-light' : '' }}">
	                    	Friends
	                    	{{ $US_freqs ? '*' : '' }}
	                    </span>
	                </a>
	            </li>
                <li class="nav-item">
	                <a class="nav-link" href="{{ route('notification.index', Auth::user()->id) }}">
                        <span class="@if ($US_noti) font-weight-bold text-light @endif">
                            Notifications
                            <span class="">
                            	<?php if( $US_noti ) echo '*'; ?>
                            </span>
                        </span>
	                </a>
	            </li>
	            @endif
	        </ul>

	        {{-- Right side of NavBar --}}
	        <ul class="navbar-nav ml-auto">
	            @if(Auth::check())
	            <li class="nav-item">
	                <a class="nav-link" href="{{ route('profile') }}">
	                    {{ Auth::user()->getFirstNameOrUsername() }}
	                </a>
	            </li>
	            <li class="nav-item">
	                <a class="nav-link" href="{{ route('logout') }}">
	                    Sign Out
	                </a>
	            </li>
	            @else
	            <li class="nav-item">
	                <a class="nav-link" href="{{ route('login') }}">
	                    Sign in
	                </a>
	            </li>
	            <li class="nav-item">
	                <a class="nav-link" href="{{ route('register') }}">
	                    Register
	                </a>
	            </li>
	            @endif
	        </ul>
	    </div>
	</nav>
