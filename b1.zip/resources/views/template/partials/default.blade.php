<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">

            <!-- Scripts -->
            <script defer="" src="{{ asset('js/app.js') }}">
            </script>

            <!-- Fonts
       		<link href="//fonts.gstatic.com" rel="dns-prefetch"/>
            <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet"/>  -->
            <link rel="stylesheet" href="{{ asset('css/font-awesome.min.css') }}">

            <!-- Styles -->
            <link href="{{ asset('css/app.css') }}" rel="stylesheet">
            <link rel="stylesheet" href="{{ asset('css/custom-styles.css') }}">
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <style>
            	.nav-link:hover{
                    color:#fff !important;
                }
            </style>
            <title>
                Hasola
            </title>
    </head>
    <?php
        $auth_user = Auth::user();
        if($auth_user){
            $US_noti = $auth_user->hasUnseenNotifications();
            $US_chats = $auth_user->hasUnseenChats();
            $US_freqs = $auth_user->hasUnseenFriendRequests();
            $US_topics = $auth_user->hasUnseenTopics();
        }else{
            $US_noti = false;
            $US_chats = false;
            $US_freqs = false;
            $US_topics = false;
        }
    ?>
    <body class="">
        {{-- navigation bar --}}
        @if($isDesktop)
            @include('template.partials.navbar')
        @else
            @include('template.partials.navbar_m')
        @endif
        {{-- alerts --}}
        @include('template.partials.alerts')

        @yield('content')
    </body>
</html>
