@extends('template.partials.default')

@section('content')

	<!-- Custom Styles -->
    <link href="{{ asset('css/custom-styles.css') }}" rel="stylesheet"/>
    <!-- End of Custom Styles -->

<div class=" {{ $isMobile ? 'container-fluid' : 'container'}} profiles-container">

	<!-- row -->
	<div class="row mt-5 d-md-flex">
		<!-- col1 -->
		<div class="{{ $isMobile ? 'col-12' : 'col-md-8'}} order-2 order-md-1">

			@if($isMobile)
						{{--############## Mobile Layout ###################--}}
				<div class="img p-2 ">
					<img src="/storage/{{ $user->getDp() }}" class="w-100 rounded-circle mb-2" alt="{{ $user->username }}">
				</div>
				<div class="intro-wrapper bg-light rounded px-3 pb-5">
					<h1 class="relative-font-2">{{ $user->getNameOrUsername() }} <span class="float-right h1"> {{ $user->location }} </span></h1>
					<h1 class="relative-font w-100">
						{{ $user->getName() ? ('@'.$user->username) : '' }}
						@if($user->isFriendWith(Auth::user()))
			                <a href="{{'/chat/'.$user->id.'#end_of_chats' }}" class="chat-button btn btn-primary btn-lg ml-auto relative-font float-right">Send Message</a>
			            @elseif($user->hasFriendRequestpending(Auth::user()))
							<span>Friend request sent</span>
			            @elseif( $user != Auth::user() && (!$user->isFriendWith(Auth::user())) )
			                <a href="/friends/add/{{ $user->id }}" class="add-friend btn btn-primary relative-font float-right">Add Friend</a>
			            @endif
			            @if(Auth()->user()->hasBlocked($user->id))
							<div class="wrapper w-100 d-block">
								<a href="/unblock/{{$user->id}}" class="btn btn-success {{ $isMobile ? 'relative-font' : ''}} float-right">UnBlock</a>
							</div>
						@else
							@if(Auth::user() == $user)
								<a href="{{ route('profile.edit') }}" class="btn btn-sm btn-success relative-font_5 float-right">Edit Profile</a>
							@else
								<a href="/block/{{$user->id}}" class="btn btn-danger relative-font float-right">Block</a>
							@endif
						@endif
						<div class="clear-fix"></div>
					</h1>
				</div>

			@else
						{{--############## Desktop Layout ###################--}}
			<div class="media d-none d-md-flex bg-light p-2 rounded shadow-cus">
				<a href="/storage/{{ $user->getDp() }}" target="_blank">
					<img src="/storage/{{ $user->getDp() }}" class=" rounded-circle mr-2 " alt="Profile Picture of {{ $user->getNameOrUsername() }}" style="max-width: {{ $isMobile ? '100%' : '70px'  }} ;">
				</a>

				<div class="media-body row">
                    <div class="left-part col-8">
                        <h1 class="mt-0 mb-1 h3 userblock_name ">{{ $user->getNameFirstNameOrUsername() }}</h1>
                        <p class="h6 ">@if($user->getName()) {{'@'.$user->username}} @endif</p>
                    </div>
                    <div class="right-part col-4">
                        @if(Auth()->user())
					@if(Auth()->user()->hasFriendRequestReceived($user))
						<div class="wrapper w-100 d-block">
							<p class="float-right">Friend Request Sent</p>
							<div class="clear-fix "></div>
						</div>
					@elseif(Auth()->user()->hasFriendRequestPending($user))
						<div class="wrapper w-100 d-block">
							<a href="/friends/accept/{{$user->id}}" class="btn btn-primary float-right">Accept friend request</a>
							<div class="clear-fix "></div>
						</div>
					@elseif(Auth()->user()->isFriendWith($user))
						<div class="wrapper w-100 d-block">
							<a class="btn btn-danger float-right" href="{{route('friends.delete',['user'=> $user])}}">Delete Friend</a>
							<div class="clear-fix "></div>
						</div>
					@elseif(!(Auth()->user() == $user))
						<div class="wrapper w-100 d-block">
							<a href="/friends/add/{{$user->id}}" class="btn btn-primary float-right">Add friend</a>
						</div>
					@elseif(Auth()->user() == $user)
						<div class="wrapper w-100 d-block">
							<a href="{{ route('profile.edit') }}" class="btn btn-primary float-right">Edit Profile</a>
						</div>
					@endif
				@endif
                        <p class="h6 user-location-right ml-auto float-right mt-2">{{ $user->location }}</p>
                    </div>
				</div>
			</div>
			@endif
			<hr class="border-dark">

			
			<div class="posts mt-md-5 {{ $isMobile ? 'relative-font' : ''}}">

				@if(!($statuses->count()))
	                <p>There's no post to show on your timeline...</p>
	            @else
	            <h5 class=" {{ $isMobile ? 'relative-font' : '' }}">
	            	{{$user->getNameOrUsername()}}'s Posts.
	            	<span style="float:right"> Total {{$statuses->count()}} posts.<span>
	            		
	            	</h5>
	                @foreach($statuses as $status)

	                    <!-- Post -->
	                    @include('posts.block')

	                @endforeach
	            @endif
			</div>

		</div>	<!-- col1 end -->

		@if($isDesktop)
			<!-- col2 -->
			<div class="col-md-4 order-1 order-md-2 friends-section">

				@if(Auth()->user() != $user) {{-- Check if This in not user's own id --}}
					@if(Auth()->user()->hasBlocked($user->id))
						<a href="/unblock/{{$user->id}}" class="btn btn-success float-right">UnBlock</a>
					@else
						<a href="/block/{{$user->id}}" class="btn btn-danger float-right">Block</a>
					@endif
				@endif

				@if(Auth()->user())
					<h3>{{ $user->getFirstNameOrUsername() }}'s Friends.</h3>
				@endif
				@if(!$user->friends()->count())
					<p>{{ $user->getFirstNameOrUsername() }} has no friends.</p>
				@else
					@foreach($user->friends() as $user)
						@include('users.partials.block')
					@endforeach
				@endif
			</div>	<!-- col2 end -->
		@endif

	</div><!-- row end -->
            <div class="row">
                <div class="col-12 d-flex justify-content-center">
                    {{$statuses->links()}}
                </div>
            </div>

</div>

@endsection
