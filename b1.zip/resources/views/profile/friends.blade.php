@extends('template.partials.default')

@section('content')
@if($isMobile)
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 your-friends">
                <h3 class="relative-font">Your Friends:</h3>
                @if(!$friends->count())
                    <p class="relative-font_5">You have no friends.</p>
                @else
                    @foreach($friends as $user)
                        @include('users.partials.block_m')
                    @endforeach
                @endif
            </div>
<hr>
            <div class="col-12 bg-light p-2 rounded relative-font friend-requests">
                <h4 class="relative-font-2">Friend requests.</h4>
                @if(!$requests->count())
                    <p class="relative-font_5">You have no friend requests.</p>
                @else
                    @foreach($requests as $user)
                        @include('users.partials.block_m')
                    @endforeach
                @endif   
            </div>

        </div>
    </div>




@else
    <div class="container">
        <div class="row">
            <!-- Friends -->
            <div class="col-md-6 order-2 order-md-1">
                <h3>Your Friends.</h3>
                @if(!$friends->count())
    				<p>You have no friends.</p>
    			@else
    				@foreach($friends as $user)
    					@include('users.partials.block')
    				@endforeach
                @endif
                <hr>
            </div>
        
            @if($isDesktop)
                <!-- Friend Requests -->
                <div class="col-md-6 order-1 order-md-2">
                    <h4>Friend requests.</h4>
                    @if(!$requests->count())
        				<p>You have no friend requests.</p>
        			@else
        				@foreach($requests as $user)
        					@include('users.partials.block')
        				@endforeach
        			@endif
                </div>
            @endif
        </div>
    </div>
@endif
@endsection
