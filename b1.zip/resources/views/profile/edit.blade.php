@extends('template.partials.default')

@section('content')

<div class="container">
	<form action="#" method="post" enctype="multipart/form-data">
		@method('put')
		@csrf
		<div class="row">
            <h1 class="col-8 offset-2">Edit Profile</h1>
        </div>
        <div class="row">
            <div class="col-8 offset-2">
                <div class="form-group row">

                <!-- First Name-->
					<div class="col-6 pl-0">
	                    <label for="first_name" class="col-form-label text-md-right">
	                        {{ "First Name" }}</label>


	                    <input id="first_name" type="text" class="form-control @error('first_name') is-invalid @enderror"
	                        name="first_name" value="{{ old('first_name') ?? $user->first_name }}" autocomplete="first_name" autofocus>

	                    @error('first_name')
	                    <span class="invalid-feedback" role="alert">
	                        <strong>{{ $message }}</strong>
	                    </span>
	                    @enderror
					</div>
                <!-- Last Name -->
				<div class="col-6 pr-0">
               		<label for="last_name" class="col-form-label text-md-right">
                        {{ "Last Name" }}</label>


                    <input id="last_name" type="text" class="form-control @error('last_name') is-invalid @enderror"
                        name="last_name" value="{{ old('last_name') ?? $user->last_name }}" autocomplete="last_name" autofocus>

                    @error('last_name')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
				</div>
                    <!-- Location -->
                    <div class="col-6 pl-0">
                        <label for="location" class="col-form-label text-md-right">
                            {{ "Location" }}</label>


                        <input id="location" type="text" class="form-control @error('location') is-invalid @enderror"
                            name="location" value="{{ old('location') ?? $user->location }}" autocomplete="location" autofocus>

                        @error('location')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>

                    {{-- Email  --}}
                    <div class="col-6 pr-0">
                        <label for="email" class="col-form-label text-md-right">
                            {{ "Email" }}</label>


                        <input id="email" type="text" class="form-control @error('email') is-invalid @enderror"
                            name="email" value="{{ old('email') ?? $user->email }}" autocomplete="email" autofocus>

                        @error('email')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                    <!-- Profile Picture -->

                    <label for="image" class="col-form-label text-md-right">
                        {{ "Profile Picture" }}</label>


                    <input id="image" type="file" class="form-control-file" name="image">

                    @error('image')

                        <strong>{{ $message }}</strong>

                    @enderror
                </div>

                <div class="row">
                    <button class="btn btn-primary" type="submit"> Update Profile</button>
                </div>
            </div>
        </div>
	</form>
</div>

@endsection
