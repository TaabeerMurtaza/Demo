@extends('template.partials.default')

@section('content')

<div class="container">
    <h2> {{ $users->count() }} results found for "{{ Request::input('query') }}"</h2>

    <div class="row">
        <div class="col-12">
            @foreach($users as $user)
                @if(!$user)
                    <h3>Sorry no results found...</h3>
                @else
                    @include('users.partials.block')
                @endif
            @endforeach
        </div>
    </div>
</div>

@endsection
