@extends('template.partials.default')

@section('content')
<!-- Custom Styles -->
<link href="{{ asset('css/custom-styles.css') }}" rel="stylesheet" />
<!-- End of Custom Styles -->

<div class="{{ $isMobile ? 'container-fluid' : 'container'}}">
    <div class="row">
        <div class="col-lg-10 shadow-cus bg-light {{ $isMobile ? 'relative-font' : '' }} p-2 rounded">
            <h3 class="{{ $isMobile ? 'h1 font-weight-bold text-uppercase' : '' }}">Notifications</h3>
            <hr>
            
                <a href="{{route('notification.read')}}" class="mar-read btn btn-primary {{ $isMobile ? 'btn-lg btn-block ' : ''}}  mb-1 mb-md-3">
                    <?php echo $isMobile ? '<h1 class="display-4">' : ''; ?>
                        Mark as read
                    <?php echo $isMobile ? '</h1>' : ''; ?></a>
            
            <ul class="list-group">
                @foreach ($notes as $noti)
                    <a href="{{ route('notification.open',$noti->id) }}"><li class="list-group-item my-1 <?php echo  ($noti->seen)?'text-dark':''; ?>">{{$noti->body}}</li></a>
                @endforeach
            </ul>
        </div>
    </div>

    <div class="row">
        <div class="col-12 d-flex justify-content-center">
            <hr>
            {{$notes->links()}} {{--  For Pagination --}}
        </div>
    </div>
</div>
@endsection
