@extends('template.partials.default')

@section('content')

<div class="container">
	<h3>Welcome to Chatty</h3>
	<div class="col-md-8 col-lg-4 pl-0">The best social network like..... ever.....Lorem idivsum dolor sit amet, consectetur adipisicing elit.</div>
</div>

@endsection
