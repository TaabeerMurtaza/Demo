@extends('template.partials.default')

@section('content')
<!-- Custom Styles -->
<link href="{{ asset('css/custom-styles.css') }}" rel="stylesheet" />
{{-- <link rel="stylesheet" href="{{ asset('css/chat_desktop.css') }}"> --}}
<!-- End of Custom Styles -->


<div class="{{ ($isMobile) ? ' container-fluid relative-font' : 'container' }}">
    <div class="row">
        <div class="h-100 {{ $isMobile ? 'col-12' : 'col-lg-9'}}">
            <div class="chats-wrapper bg-light border my-2">
                @foreach ($chats as $chat)
                    @if($chat->user_id == $other->id)

                      {{-- INCOMING!!! --}}
                      <div class="media my-2 p-1 ">
                        <img src="/storage/{{ $chat->other()->getDp() }}" class="mr-3 {{ $isMobile ? 'chat-dp-2' : 'chat-dp'}} rounded-circle" alt="{{ $chat->other()->getFirstNameOrUsername() }}">
                        <div class="media-body">
                            <h6 class="rounded bg-secondary p-2 pr-auto text-light w-75 mb-0 chat-body {{ $isMobile ? 'relative-font' : '' }}">
                                {{ $chat->body }}
                            </h6>
                            <span class="time small text-secondary float-left">{{ $chat->getTime() }}</span>
                          </div>
                        </div>
                    
                    @else

                      {{-- Out Going --}}
                      <div class="media my-2 p-1 ">
                        <div class="media-body">
                            <div class="float-right w-75">
                                <h6 class="rounded bg-info p-2 pr-auto text-light chat-body {{ $isMobile ? 'relative-font' : '' }} mb-0">
                                    {{ $chat->body }}
                                </h6>
                                <span class="time small text-secondary float-left">{{ $chat->getTime() }}</span>
                            </div>
                        </div>

                        </div>

                    @endif
                @endforeach

                <!-- Custom Javascript -->
                <script>
                    $(document).ready(function() {
                    $.ajaxSetup({
                        headers: {
                          'X-CSRF-Token': $('meta[name="_token"]').attr('content')
                        }
                      });
                    });
                    xhttp.onreadystatechange = function() {
                      if (xhttp.readyState == 4 && xhttp.status == 200) {
                        document.getElementById("msg").innerHTML = xhttp.responseText;
                      }
                    };
                    xhttp.open("GET", "fetch_msgs.php", true);
                    xhttp.send();
                </script>
                <!-- End of custom JS -->
                <hr id="end_of_chats">
            </div>


            <form role="form" action="{{ route('chat.post', $other) }}" method="post" enctype="multipart/form-data" class="bg-light shadow-cus p-2 rounded">
                @csrf
                {{-- Post Text --}}
                <div class="form-group {{ $errors->has('msg')? ' has-error' : ''}}">
                    <input name="msg" class="form-control needs-validation {{ $isMobile ? 'relative-font p-5p' : '' }}"
                        placeholder="What's up {{ auth()->user()->getFirstNameOrUsername() }}?" required>
                    @if($errors->has('msg'))
                    <span class="help-block">{{ $errors->first('msg') }}</span>
                    @endif
                </div>
                {{-- Post Image --}}
                <div class="form-group {{ $errors->has('head_image')? ' has-error' : ''}}">
                    <input type="file" name="head_image" class="form-control needs-validation h-100 {{ $isMobile ? 'relative-font' : '' }}">
                    @if($errors->has('head_image'))
                    <span class="help-block">{{ $errors->first('head_image') }}</span>
                    @endif
                </div>
                <button type="submit" class="btn btn-primary {{ $isMobile ? 'relative-font mb-5p' : '' }}" value="Post">Post</button>
            </form>

            {{-- JS code to disable invalid form submission --}}
            <script>

                (function() {
                  'use strict';
                  window.addEventListener('load', function() {
                    // Fetch all the forms we want to apply custom Bootstrap validation styles to
                    var forms = document.getElementsByClassName('needs-validation');
                    // Loop over them and prevent submission
                    var validation = Array.prototype.filter.call(forms, function(form) {
                      form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                          event.preventDefault();
                          event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                      }, false);
                    });
                  }, false);
                })();
            </script>


        </div>

        {{-- Right Part (Friends) --}}
        <div class="d-none d-lg-block col-lg-3 order-1 order-md-2">
            <h3>Your friends:</h3>
			@if(!Auth::user()->friends()->count())
				<p>You have no friends.</p>
			@else
				@foreach(Auth::user()->friends() as $user)
					@include('users.partials.compact')
				@endforeach
			@endif
		</div>
    </div>

</div>
@endsection
