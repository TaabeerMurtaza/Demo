@extends('template.partials.default')

@section('content')
<!-- Custom Styles -->
<link href="{{ asset('css/custom-styles.css') }}" rel="stylesheet" />
<!-- End of Custom Styles -->


<div class=" {{ $isMobile ?  'relative-font' : ''}} container-fluid">
    <div class="row">
        <div class="{{ $isMobile ? 'col-12' : 'col-md-8'}}">
            <h3 class="bg-light p-2 rounded text-center mb-0 {{ $isMobile ? 'relative-font' : '' }}">Recent Chats:</h3>
            <hr class="my-0">
            <div class="chat-list bg-light">
            @foreach($final as $chat)
                @if($chat->other())
                  <a href="{{ route('chat.chat', $chat->other()->id) }}" class="text-dark">
                      <div class="media p-2">
                        <img src="/storage/{{ $chat->other()->getDp() }}" class="mr-3 user-dp rounded-circle" alt="{{ $chat->other()->username }}">
                        <div class="media-body">
                          <h5 class="mt-0 {{ $isMobile ? 'relative-font' : '' }}">{{ '@'.$chat->other()->username }} <span class=" small float-right">{{ $chat->getdate() }}</span></h5>

                          <span class="text-secondary d-block one-line">
                            {{ $chat->body }}
                          </span>
                        </div>
                      </div>
                    </a>
                @endif
                <hr class="border-secondary">
            @endforeach
            </div>

            <hr>
        </div>


          {{-- Right section --}}
        @if(!$isMobile)
        {{-- Horizontal seperator --}}
        <div class="h-75 ver_col d-none d-md-block"></div>
          <div class="d-none d-md-block col-md-4   order-1 order-md-2">
                <h3>Your friends:</h3>
      			@if(!$user->friends()->count())
      				<p>You have no friends.</p>
      			@else
      				@foreach($user->friends() as $user)
      					@include('users.partials.block')
      				@endforeach
      			@endif
    		</div>
        @endif
    </div>

</div>

@endsection

