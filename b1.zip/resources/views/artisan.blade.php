<form action="{{ route('artisan.post') }}" method="post">
	@csrf
	<input type="text" name="command">
	<input type="submit" value="submit" class="btn btn-primary">
</form>