@extends('template.partials.default')

@section('content')

	<!-- Custom Styles -->
    <link href="{{ asset('css/custom-styles.css') }}" rel="stylesheet"/>
    <!-- End of Custom Styles -->
@if($isDesktop)
	<div class=" {{ $isMobile ? 'container-fluid' : 'container'}} profiles-container">

		<!-- row -->
		<div class="row mt-5 d-md-flex">

		{{-- Topic Search --}}
		<div class="{{ $isMobile ? 'col-12' : 'col-md-12 ' }} p-2 ">
			<form class="form-inline my-2 my-lg-0" role="search" action="{{ route('search.topic') }}">
		        <input aria-label="Search" class="form-control mr-sm-2" placeholder="Search Topics" type="search" name="query">
		        <button class="btn btn-success my-2 my-sm-0" type="submit">
		            Search
		        </button>
		    </form>
		</div>

			<!-- col1 -->
			<div class="{{ $isMobile ? 'col-12' : 'col-md-12'}}">

				{{-- Searched Topics --}}
				<ul class="list-group">
					<li class="active list-group-item">Search Results:</li>
					@foreach($searched_topics as $topic)
					  <a href="{{ route('topic.open', ['id' => $topic->id]) }}"><li class="list-group-item">{{ $topic->name }}</li></a>
					@endforeach
				</ul>	

			</div> <!-- col1 end -->

		</div><!-- row end -->

	</div>

@else

<div class="row">
	<div class="col-12">
		{{-- Search Bar --}}
		<form class="form-inline my-2 my-lg-0 mr-auto re" role="search" action="{{ route('search.topic') }}">
	        <input aria-label="Search" class="form-control mr-sm-2 relative-font p-5p" placeholder="Search Topics" type="search" name="query">
	        @error('topicName')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
	        <button class="btn btn-success my-2 my-sm-0 relative-font" type="submit">
	            Search
	        </button>
	    </form>
		

		{{-- Searched Topics --}}
		<ul class="list-group">
			<li class="active list-group-item relative-font">Search Results:</li>
			@foreach($searched_topics as $topic)
			  <a href="{{ route('topic.open', ['id' => $topic->id]) }}"><li class="list-group-item relative-font">{{ $topic->name }}</li></a>
			@endforeach
		</ul>	


	</div>
</div>



@endif

@endsection
