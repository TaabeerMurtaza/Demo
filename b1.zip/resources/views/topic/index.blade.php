@extends('template.partials.default')

@section('content')

@if($isDesktop)
	<div class="container profiles-container">

		<!-- row -->
		<div class="row mt-5">

			<!-- col1 -->
			<div class="{{ $isMobile ? 'col-12' : 'col-md-8'}}">

				<form role="form" action="{{ route('topic.create') }}" method="post" class="">
		        @csrf
				  <div class="form-group">
				    <label for="topicName ">Create New Topic</label><br>
				    <input type="text" name="topicName" class="form-control mr-auto w-auto d-inline shadow-cus" id="topicName" aria-describedby="" placeholder="Enter topic name" value="{{ old('topicName') }}" required="">

					<button type="submit" class="btn btn-primary shadow-cus">Create Topic</button>
					@error('topicName')
	                    <span class="invalid-feedback d-block" role="alert">
	                        <strong>{{ $message }}</strong>
	                    </span>
	                @enderror
					<div class="clear-fix"></div>
				  </div>
				  
				</form>
				{{-- Owned Topics --}}
				<ul class="list-group shadow-cus">
					<li class="active list-group-item">My Topics:</li>
					@foreach($myTopics as $topic)
					  <a href="{{ route('topic.open', ['id' => $topic->id]) }}">
					  	<li class="list-group-item">
					  		{{ $topic->name }}
							

							<div class="float-right">
								<span class="last-post-preview text-secondary half-opacity">
									{{ $topic->getLastPost() ? substr($topic->getLastPost()->body, 0, 30) : '' }}
								</span>


								<span class="badge bg-purple badge-pill "> {{ Auth::user()->isAdminOfTopic($topic) ? 'admin' : count($topic->posts) }}</span> 
							</div>
					  	</li>	
					  </a>
					@endforeach
				</ul>	





				


			</div> <!-- col1 end -->

			{{-- Col2 --}}
			<div class="{{ $isMobile ? 'col-12' : 'col-md-4'}}">

				{{-- Search bar --}}
			    <label for="topicName mr-auto">Search for topic</label>
			    <form class="form-inline my-2 my-lg-0 d-block" action="{{ route('search.topic') }}">
			    	<div class="form-group mb-3">
					    <input class="form-control mr-sm-2 shadow-cus" type="search" placeholder="Search" aria-label="Search">
					    <button class="btn btn-success my-2 my-sm-0 shadow-cus" type="submit">Search</button>
				    </div>
			    </form>


				{{-- Other Topics list --}}

				<ul class="list-group shadow-cus">
					<li class="list-group-item active">Browse Topics</li>
					<div class="browse-topics">
						
					@foreach($topics as $topic)
					  <a href="{{ route('topic.open', ['id' => $topic->id]) }}"><li class="list-group-item">{{ $topic->name }}</li></a>
					@endforeach
					</div>
				</ul>
				
				
			</div>
		

		<!-- Modal -->
		<div class="modal fade" id="searchTopicModal" tabindex="-1" role="dialog" aria-labelledby="searchTopicModalLabel" aria-hidden="true">
		  <div class="modal-dialog" role="document">
		    <div class="modal-content">

		      <div class="modal-header">
		        <h5 class="modal-title" id="searchTopicModalLabel">Search Topic</h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		        </button>
		      </div>

		      <div class="modal-body">

		        

		      </div>

		      </div>
		    </div>
		  </div>
		{{-- Modal Ends here --}}

		</div><!-- row end -->

	</div>


@else
<div class="row">

	<div class="col-12">
		<form role="form" action="{{ route('topic.create') }}" method="post">
        @csrf
			<div class="form-group">
				<label for="topicName" class="relative-font">Create Topic  </label><a href="{{ route('topic.other') }}" class="float-right relative-font">Browse	 topics</a>
				<input type="text" name="topicName" class="form-control relative-font p-5p" id="topicName" aria-describedby="emailHelp" placeholder="Enter topic name" required="">
				@error('topicName')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
				<button type="submit" class="btn btn-primary float-right relative-font">Save</button>
				<hr class="border-dark">
				<div class="clear-fix"></div>
			</div>
		</form>

		{{-- Owned Topics --}}
		<ul class="list-group">
			<li class="active list-group-item relative-font mb-2">My Topics:</li>
			@foreach($ownedTopics as $topic)
			  <a href="{{ route('topic.open', ['id' => $topic->id]) }}"><li class="list-group-item relative-font">{{ $topic->name }}</li></a>
			@endforeach
		</ul>

	</div>



</div>
@endif

@endsection
