@extends('template.partials.default')

@section('content')

	<!-- Custom Styles -->
    <link href="{{ asset('css/custom-styles.css') }}" rel="stylesheet"/>
    <!-- End of Custom Styles -->
@if($isMobile)
<div class="row">
	<div class="col-12">
		{{-- Search Bar --}}
		<form class="form-inline my-2 my-lg-0 mr-auto re" role="search" action="{{ route('search.topic') }}">
	        <input aria-label="Search" class="form-control mr-sm-2 relative-font p-5p" placeholder="Search Topics" type="search" name="query">
	        @error('topicName')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
	        <button class="btn btn-success my-2 my-sm-0 relative-font" type="submit">
	            Search
	        </button>
	        <div class="clear-fix"></div>
	    </form>
		

		{{-- Other Topics list --}}
		<ul class="list-group">
			<li class="list-group-item active relative-font">Browse Topics</li>
			@foreach($unownedTopics as $topic)
			  <a href="{{ route('topic.open', ['id' => $topic->id]) }}"><li class="list-group-item relative-font">{{ $topic->name }}</li></a>
			@endforeach
		</ul>


	</div>
</div>



@endif

@endsection
