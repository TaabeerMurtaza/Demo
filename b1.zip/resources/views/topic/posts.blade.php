@extends('template.partials.default')

@section('content')

	<!-- Custom Styles -->
    <link href="{{ asset('css/custom-styles.css') }}" rel="stylesheet"/>
    <!-- End of Custom Styles -->

<div class=" {{ $isMobile ? 'container-fluid' : 'container'}} profiles-container">

	<!-- row -->
	<div class="row mt-5 d-md-flex">
        <!-- col1 -->
		<div class="{{ $isMobile ? 'col-12' : 'col-md-8'}} order-2 order-md-1">

            @if($isMobile)
                        {{--############## Mobile Layout ###################--}}
                <div class="intro-wrapper bg-light rounded px-3 pb-5">
                    <h1 class="relative-font-2 text-primary">
                        {{ $topic->name }}
                        @if(Auth()->user()->isMemberOfTopic($topic) || Auth::user()->isAdminOfTopic($topic))
                            <a href="{{ route('topic.leave', ['id' => $topic->id]) }}" class="btn btn-danger relative-font_5 float-right">Leave Topic</a>
                        @else
                            <a href="{{ route('topic.join', ['id' => $topic->id]) }}" class="btn btn-success relative-font_5 float-right">Join Topic</a>
                        @endif
                    </h1>
                </div>

            @else
                        {{--############## Desktop Layout ###################--}}
            <div class="media d-none d-md-flex bg-light p-2 rounded shadow-cus">

                <div class="media-body row">
                    <div class="left-part col-8">
                        <h1 class="mt-0 mb-1 h3 userblock_name text-success">{{ $topic->name }}</h1>
                    </div>


                    {{-- To be added later --}}
                    {{-- <div class="right-part col-4">
                        @if(Auth()->user()->hasFriendRequestReceived($user))
                            <div class="wrapper w-100 d-block">
                                <p class="float-right">Friend Request Sent</p>
                                <div class="clear-fix "></div>
                            </div>
                        @elseif(Auth()->user()->hasFriendRequestPending($user))
                            <div class="wrapper w-100 d-block">
                                <a href="/friends/accept/{{$user->id}}" class="btn btn-primary float-right">Accept friend request</a>
                                <div class="clear-fix "></div>
                            </div>
                        @elseif(Auth()->user()->isFriendWith($user))
                            <div class="wrapper w-100 d-block">
                                <a class="btn btn-danger float-right" href="{{route('friends.delete',['user'=> $user])}}">Delete Friend</a>
                                <div class="clear-fix "></div>
                            </div>
                        @elseif(!(Auth()->user() == $user))
                            <div class="wrapper w-100 d-block">
                                <a href="/friends/add/{{$user->id}}" class="btn btn-primary float-right">Add friend</a>
                            </div>
                        @elseif(Auth()->user() == $user)
                            <div class="wrapper w-100 d-block">
                                <a href="{{ route('profile.edit') }}" class="btn btn-primary float-right">Edit Profile</a>
                            </div>
                        @endif

                        <p class="h6 user-location-right ml-auto float-right mt-2">{{ $user->location }}</p>
                    </div> --}}
                </div>
            </div>
            @endif
            <hr class="border-dark">

            <div class="posts mt-md-5 {{ $isMobile ? 'relative-font' : ''}}">
                
                <form role="form" action="{{ route('topic.post', ['id' => $topic->id]) }}" method="post" enctype="multipart/form-data" class="">
                    @csrf
                    {{-- Post Text --}}
                    <div class="form-group shadow-cus bg-light p-2 {{ $errors->has('post')? ' has-error' : ''}}">
                        <label for="create_post" class=" {{ $isMobile ? 'relative-font' : ''}}">Create a new Post</label>
                        <textarea name="post" rows="2" id='create_post' class="form-control {{ ($isMobile) ? 'relative-font' : '' }}"
                            placeholder="What's up {{ auth()->user()->getFirstNameOrUsername() }}?">{{ old('post') }}</textarea>
                        @if($errors->has('post'))
                        <span class="help-block text-danger">{{ $errors->first('post') }}</span>
                        @endif
                    </div>
                    {{-- Post Image --}}
                    <div class="form-group shadow-cus {{ $errors->has('head_image')? ' has-error' : ''}}">
                        <input type="file" name="head_image" class="form-control h-auto {{ ($isMobile) ? 'relative-font' : '' }}">
                        @if($errors->has('head_image'))
                        <span class="help-block">{{ $errors->first('head_image') }}</span>
                        @endif
                    </div>
                    <button type="submit" class="btn btn-primary {{ ($isMobile) ? 'relative-font' : '' }}" value="Post">Post</button>
                </form>

                @if(!($posts->count()))
                    <p>There's no post on this topic.</p>
                @else
                <h5 class=" {{ $isMobile ? 'relative-font' : '' }}">
                    Posts on topic {{ $topic->name }}
                    <span style="float:right"> Total {{$posts->count()}} posts.<span>
                        
                    </h5>
                    @foreach($posts as $status)

                        <!-- Post -->
                        @include('posts.block')

                    @endforeach
                @endif
            </div>

        </div> <!-- col1 end -->

        @if($isDesktop)
            <!-- col2 -->
            <div class="col-md-4 order-1 order-md-2 friends-section">
                @if(Auth()->user()->isMemberOfTopic($topic) || Auth::user()->isAdminOfTopic($topic))
                    <div class="d-block">
                        <a href="{{ route('topic.leave', ['id' => $topic->id]) }}" class="btn btn-danger float-right">Leave Topic</a>
                        <div class="clear-fix"></div>
                    </div>
                @else
                    <div class="d-block">
                        <a href="{{ route('topic.join', ['id' => $topic->id]) }}" class="btn btn-success float-right">Join Topic</a>
                        <div class="clear-fix"></div>
                    </div>
                @endif
                <hr>
                @foreach($users as $user)
                    @include('users.partials.block_topic')
                @endforeach
                
            </div>  <!-- col2 end -->
        @endif


	</div><!-- row end -->

    <div class="row">
        <div class="col-12 d-flex justify-content-center">
            {{$posts->links()}}
        </div>
    </div>

</div>

@endsection
