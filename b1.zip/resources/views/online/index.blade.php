@extends('template.partials.default')

@section('content')

	<!-- Custom Styles -->
    <link href="{{ asset('css/custom-styles.css') }}" rel="stylesheet"/>
    <!-- End of Custom Styles -->

<div class="{{ ($isMobile) ? 'relative-font container-fluid' : 'container' }} profiles-container">

	<!-- row -->
	<div class="row mt-5 d-md-flex">
		<!-- col1 -->
		<div class=" @if($isMobile) col-12 @else col-md-8 order-2 order-md-1 @endif">

            <h3>All is well</h3>

		</div>	<!-- col1 end -->

		<!-- col2 -->
		<div class="d-none d-md-block col-md-4 order-1 order-md-2 friends-section">
			

		</div>	<!-- col2 end -->


	</div><!-- row end -->

</div>

@endsection
