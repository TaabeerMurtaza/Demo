@extends('template.partials.default')

@section('content')
<!-- Custom Styles -->
<link href="{{ asset('css/custom-styles.css') }}" rel="stylesheet" />
<!-- End of Custom Styles -->
<div class="@if($isMobile) flex-container mx-1 relative-font @else container @endif">
    <div class="row">
        <div class="@if($isMobile) col-12 @else col-lg-10 @endif bg-light shadow-cus p-2 rounded">
            @if(Auth::check())
                <form role="form" action="{{ route('timeline.update') }}" method="post" enctype="multipart/form-data">
                    @csrf
                    {{-- Post Text --}}
                    <div class="form-group {{ $errors->has('status')? ' has-error' : ''}}">
                        <textarea name="status" rows="2" class="form-control {{ ($isMobile) ? 'relative-font' : '' }}"
                            placeholder="What's up {{ auth()->user()->getFirstNameOrUsername() }}?">{{ old('status') }}</textarea>
                        @if($errors->has('status'))
                        <span class="help-block text-danger font-weight-bold">{{ $errors->first('status') }}</span>
                        @endif
                    </div>
                    {{-- Post Image --}}
                    <div class="form-group {{ $errors->has('head_image')? ' has-error' : ''}}">
                        <input type="file" name="head_image" class="form-control h-auto {{ ($isMobile) ? 'relative-font' : '' }}">
                        @if($errors->has('head_image'))
                        <span class="help-block">{{ $errors->first('head_image') }}</span>
                        @endif
                    </div>
                    <button type="submit" class="btn btn-primary {{ ($isMobile) ? 'relative-font' : '' }}" value="Post">Post</button>
                </form>
            @endif
            <hr>
        </div>
    </div>
    <div class="row">
        <div class="@if($isMobile) col-12 @else col-lg-8 col-xl-8 @endif text-md-justify ">
            @if(!($statuses->count()))
            <p>There's no post to show on your timeline...</p>
            @else
            @foreach($statuses as $status)

            <!-- Post -->
            @include('posts.block')

            @endforeach
            @endif
        </div>
        
        @if($isDesktop)
            <div class="col-4 mt-2">
                {{-- Owned Topics --}}
                <ul class="list-group shadow-cus">
                    <li class="active list-group-item">My Topics:</li>
                    @if($myTopics)
                        @foreach($myTopics as $topic)
                          <a href="{{ route('topic.open', ['id' => $topic->id]) }}">
                            <li class="list-group-item">
                                {{ ( strcspn($topic->name, '!@#^%$#') > 20 ) ? ( substr($topic->name, 0, 20).'...' ) : $topic->name }}

                                <div class="float-right">
                                    <span class="badge bg-purple badge-pill "> {{ Auth::user()->isAdminOfTopic($topic) ? 'admin' : count($topic->posts) }}</span> 
                                </div>
                            </li>   
                          </a>
                        @endforeach
                    @endif
                </ul>
            </div>
        @endif

    </div>
    <div class="row">
        <div class="col-12 d-flex justify-content-center">
            {{$statuses->links()}}
        </div>
    </div>
</div>
@endsection
