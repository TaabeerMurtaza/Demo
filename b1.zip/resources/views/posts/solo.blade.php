@extends('template.partials.default')

@section('content')

<div class="{{ ($isMobile) ? 'relative-font container-fluid' : 'container' }} profiles-container">

	<!-- row -->
	<div class="row mt-5 d-md-flex">
		<!-- col1 -->
		<div class=" @if($isMobile) col-12 @else col-md-8 order-2 order-md-1 @endif">

            {{-- Post --}}
			<div class="shadow-cus bg-light rounded {{ $isMobile ? 'p-2p mb-5p' : 'p-2' }} m-2">
                <div class="media bg-none @if($isMobile) relative-font mx-md-1 my-md-3 @endif w-100" id="{{ $status->id }}">
                    <div class="media-body alert alert-secondary mb-1">
                        <div class="d-flex flex-row">

                            {{-- Post DP --}}
                            <img src="/storage/@if($status->user->image){{$status->user->image}}@else{{ 'dp.png' }}@endif"
                             class="rounded-custom mr-2 mr-lg-3 media-object post-dp h-100" alt="Profile Picture">

                            <a href="{{ route('profile.index', [$status->user_id]) }}" class="w-100">
                                <h3 class="media-heading mt-0 @if($isMobile) relative-font ml-3 mb-0 @else mb-1 @endif mb-1">
                                    <span class="text-dark mb-auto">
                                        <u>{{  '@'.$status->user->username }}</u>
                                    </span>
                                </h3>
                            </a>
                            @if($status->user_id == Auth::user()->id || Auth::user()->isAdmin()) <a href="{{route('timeline.delete', $status->id)}}" class="btn {{ $isMobile ? 'btn-lg' : '' }} btn-danger float-right text-large {{ $isMobile ? 'my-auto' : 'mb-auto'}}">Delete</a> @endif
                        </div>

                            {{-- Post head_image --}}
                        <div class="post-image">
                            @if($status->head_image)
                                <img src="/storage/{{ $status->head_image }}" class="w-100 mt-2">
                            @endif

                            
                        </div>

                        {{-- Post text --}}
                        <div class="post-text mt-1 ">{{ $status->body }}</div>
                        <hr class="my-1">

                        {{-- like --}}
                        <ul class="list-inline d-flex {{ $isMobile ? 'h3' : '' }}">
                            <a href="{{route('status.like', $status->id)}}">
                                <li class="px-3">Like</li>
                            </a>
                            <li>{{$status->likes()->count()}} {{ Str::plural("like",$status->likes()->count() )}}</li>
                            <li class="ml-auto ">{{ $status->created_at->diffForHumans() }}</li>
                        </ul>


                        

                    </div>
                </div>

                <!-- Reply count -->
                @if($status->replies()->count() > 0)
                    <span class=" {{ $isMobile ? 'bg-info display-4 text-light text-center' : '' }} rounded px-2 w-100 d-block mb-1">
                        {{$status->replies()->count() }} {{Str::plural("reply",$status->replies()->count() )}}
                    </span>
                @endif

                <!-- Post Form..... -->
                <form role="form" action="{{ route('timeline.reply',[ 'statusId' => $status->id]) }}" method="post" class=" {{ $isDesktop ? 'mb-2' : '' }}">
                    @csrf
                    <div class="form-group @if($isDesktop) mb-1 @endif @error('name') is-invalid @enderror">
                        <textarea name="reply-{{$status->id}}" rows="1" class="form-control {{ ($isMobile) ? 'relative-font' : '' }}"
                            placeholder="Post Reply..." required></textarea>
                        @error('name')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('reply-{$status->id}') }}</strong>
                        </span>

                        @enderror

                    </div>
                    <button type="submit" class="btn btn-primary {{ ($isMobile) ? 'relative-font' : '' }}" value="Post">Reply</button>
                </form>
                </div>

    			<div class="posts mt-md-3 {{ ($isMobile) ? 'relative-font ' : '' }}">
    			@if(!($status))
                    <p>Status not Found</p>
                @else


                <hr>

<!-- Replies -->
@foreach($replies as $reply)
    <div class="shadow-cus bg-light rounded {{ $isMobile ? 'p-2p mb-5p' : 'p-2' }} m-2">
        <div class="media mx-1 my-3" id="{{$reply->id}}">
            <div class="media-body w-100">

                {{-- Reply DP --}}
                <img src="/storage/@if($reply->user->image){{$reply->user->image}}@else{{ 'dp.png' }}@endif" class="w-100 rounded mr-2 mr-lg-3 mb-2 media-object reply-dp" alt="Profile Picture">
                {{-- Reply Username --}}
                <a href="{{ route('profile.index', [$reply->user_id]) }}">{{ $reply->user->getNameOrUsername() }}
                    @if($reply->user_id == Auth::user()->id || Auth::user()->isAdmin()) <a href="{{route('timeline.delete', $reply->id)}}" class="btn-lg btn-danger float-right text-large">Delete</a> @endif
                </a>

                {{-- Reply Text --}}
                <div class="reply-text alert alert-secondary w-100">{{ $reply->body }}</div>

                <hr>

                {{-- like --}}
                <ul class="list-inline d-flex {{ $isMobile ? 'h3' : '' }}">
                    <a href="{{route('status.like', $reply->id)}}">
                        <li class="px-3">Like</li>
                    </a>
                    <li>{{$reply->likes()->count()}} {{ Str::plural("like",$reply->likes()->count() )}}</li>
                    <li class="ml-auto ">{{ $reply->created_at->diffForHumans() }}</li>
                </ul>

            </div>
        </div>

    </div>
@endforeach


            @endif
			</div>

		</div>	<!-- col1 end -->

		<!-- col2 -->
		<div class=" {{ $isMobile ? 'd-none ' : 'd-md-block' }} col-md-4 order-1 order-md-2 ">
			<h3>{{ count($partis)}} {{Str::plural("Participant",count($partis) )}}</h3>

			@if(!count($partis))
				<p>This post has no participants.</p>
			@else
				@foreach($partis as $user)
					@include('users.partials.block')
				@endforeach
			@endif
		</div>	<!-- col2 end -->


	</div><!-- row end -->

</div>
   <div class="row w-100 {{ $isMobile ? 'mb-5p' : ''}}">
        <div class="col-12 d-flex justify-content-center {{ $isMobile ? 'display-4 mb-3' : '' }} ">
            {{$replies->links()}}
        </div>
    </div>

@endsection
