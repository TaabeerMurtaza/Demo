<div class="media mx-md-1 my-md-3 @if($isMobile) relative-font @endif w-100" id="{{ $status->id }}">
    <div class="media-body">
    <img src="/storage/@if($status->user->image){{$status->user->image}}@else{{ 'dp.png' }}@endif" class=" rounded-custom mr-2 mr-lg-3 media-object post-dp" alt="Profile Picture">
        <a href="{{ route('profile.index', [$status->user_id]) }}">{{ $status->user->getNameOrUsername() }}
            <h1 class="media-heading mt-0 mb-1 h3"></h1></a>
            {{-- Post DP --}}
        <div class="post-image">
            @if($status->head_image)
                <img src="/storage/{{ $status->head_image }}" class="w-100">
            @endif
        </div>

        {{-- Post text --}}
        <div class="post-text mt-1 alert alert-dark">{{ $status->body }}</div>
        <hr class="my-1">

        {{-- like --}}
        <ul class="list-inline d-flex">
            <li>{{ $status->created_at->diffForHumans() }}</li>
            <a href="{{route('status.like', $status->id)}}">
                <li class="px-3">Like</li>
            </a>
            <li>{{$status->likes()->count()}} {{ Str::plural("like",$status->likes()->count() )}}</li>
            <li class="ml-auto "></li>
        </ul>


        <!-- Reply -->
        <?php
            $rp = [];
            $st = $status->replies()->latest()->get();
            foreach ($st as $key => $value) {
                if($key < 2)$rp[$key] = $value;
            }
        ?>
        @if($status->replies()->count() >2)
            <a href="{{ route('status.open', $status->id) }}" class="bg-info text-light rounded px-2 w-100 d-block">
                {{$status->replies()->count() }} {{Str::plural("reply",$status->replies()->count() )}}
            </a>
        @endif
        @foreach($rp as $reply)
        <div class="media mx-1 my-3" id="{{$reply->id}}">

            {{-- reply dp --}}
            <img src="/storage/@if($reply->user->image){{$reply->user->image}}@else{{ 'dp.png' }}@endif" class=" rounded-custom mr-2 mr-lg-3 media-object reply-dp" alt="Profile Picture">
            <div class="media-body">
                <a href="{{ route('profile.index', [$reply->user_id]) }}">{{ $reply->user->getNameOrUsername() }}
                    <h1 class="media-heading mt-0 mb-1 h3"></h1></a>

                {{-- Reply text --}}
                <div class="post-text  alert alert-dark">{{ $reply->body }}</div>
                <ul class="list-inline d-flex">
                    <li>{{ $reply->created_at->diffForHumans() }}</li>
                    <a href="{{route('status.like', $reply->id)}}">
                        <li class="px-3">Like</li>
                    </a>
                    <li>{{$reply->likes()->count()}} {{ Str::plural("like",$reply->likes()->count() )}}</li>
                </ul>
            </div>
        </div>
        @endforeach

        <!-- Post Form..... -->
        <form role="form" action="{{ route('timeline.reply',[ 'statusId' => $status->id]) }}" method="post">
            @csrf
            <div class="form-group @error('name') is-invalid @enderror">
                <textarea name="reply-{{$status->id}}" rows="1" class="form-control {{ ($isMobile) ? 'relative-font' : '' }}"
                    placeholder="Post Reply..." required></textarea>
                @error('name')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('reply-{$status->id}') }}</strong>
                </span>

                @enderror

            </div>
            <button type="submit" class="btn btn-primary {{ ($isMobile) ? 'relative-font' : '' }}" value="Post">Reply</button>
        </form>
    </div>
</div>
